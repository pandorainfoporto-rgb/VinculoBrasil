
- User wants to integrate Slack (integrationId: "mcp:688338e4ee9e1a9340d83b62") - Automate workflows and communications in your workspace.
- User wants to integrate Github (integrationId: "mcp:686de4e26fd1cae1afbb55bc") - Automate your development lifecycle and repository workflows.
- User wants to integrate Notion (integrationId: "mcp:686de4616fd1cae1afbb55b9") - Build custom workflows for your docs and databases.
User explicitly requested integrations. Use `fetch_integration_method_list` to fetch methods list, then install necessary methods with `install_integrations`, and use them in your code.