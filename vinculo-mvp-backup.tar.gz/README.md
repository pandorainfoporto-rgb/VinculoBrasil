# Vinculo.io - Blockchain Real Estate Protocol

> A evolucao da locacao imobiliaria: Contratos inteligentes, garantias tokenizadas e transparencia absoluta.

[![React](https://img.shields.io/badge/React-19-61DAFB?style=flat&logo=react)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=flat&logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.0-06B6D4?style=flat&logo=tailwindcss)](https://tailwindcss.com/)
[![Solidity](https://img.shields.io/badge/Solidity-0.8-363636?style=flat&logo=solidity)](https://soliditylang.org/)
[![Polygon](https://img.shields.io/badge/Polygon-MATIC-8247E5?style=flat&logo=polygon)](https://polygon.technology/)

---

## Sobre o Projeto

O **Vinculo.io** e um ecossistema completo de locacao de imoveis que elimina a burocracia tradicional brasileira ao integrar a **Lei do Inquilinato (8.245/91)** com a tecnologia **Blockchain**.

O projeto transforma contratos de aluguel em **NFTs** e utiliza imoveis de garantidores como **colaterais digitais** (Collateralized Debt Positions), garantindo liquidez imediata e seguranca juridica para todas as partes.

### Modelo Financeiro: Split 85/5/5/5

Cada pagamento de aluguel e automaticamente dividido via Smart Contract:

| Destinatario | Percentual | Descricao |
|--------------|------------|-----------|
| **Locador** | 85% | Proprietario do imovel |
| **Seguradora** | 5% | Fiadora digital |
| **Plataforma** | 5% | Taxa Vinculo.io |
| **Garantidor** | 5% | Comissao por garantia |

---

## Atores do Ecossistema

| Ator | Funcao |
|------|--------|
| **Locador** | Gestao de patrimonio com repasses automatizados via Smart Contract |
| **Locatario** | Experiencia de locacao agil, sem necessidade de caucao em dinheiro |
| **Garantidor** | Terceiro que disponibiliza um ativo imobiliario como garantia tokenizada |
| **Seguradora** | Fiadora digital que audita riscos e garante o pagamento mensal |
| **Admin** | Orquestrador e arbitro em casos de disputa de vistoria ou inadimplencia |

---

## Principais Funcionalidades

### Tokenizacao de Contratos (NFT)
Cada locacao gera um NFT unico contendo metadados de vistoria, valores e prazos. O contrato e imutavel e auditavel na blockchain.

### Collateral Lock (Bloqueio de Garantia)
Bloqueio inteligente de ativos de garantia na blockchain, impedindo dupla alienacao. O imovel do garantidor fica "travado" ate o fim do contrato.

### Split de Pagamento Automatico
Distribuicao instantanea de valores para Locador, Seguradora, Plataforma e Garantidor via Smart Contract. Sem intermediarios.

### Vistoria Digital Imutavel
Registro de evidencias fotograficas e videos no IPFS com integridade garantida por hashes on-chain. Comparacao automatica entrada vs saida.

### Sistema Multi-Sig (2 de 3)
Acoes criticas requerem 2 de 3 assinaturas:
- Administrador
- Seguradora
- Parte Interessada (Locador ou Locatario)

### Resolucao de Disputas
Fluxo completo de arbitragem com:
- Falha de pagamento
- Danos na vistoria
- Rescisao de contrato
- Liberacao de garantia

---

## Tech Stack

### Frontend
- **React 19** - Framework UI
- **TypeScript** - Tipagem estatica
- **Tailwind CSS v4** - Estilizacao
- **shadcn/ui** - Componentes UI (New York style)
- **TanStack Router** - Roteamento
- **TanStack Query** - Gerenciamento de estado servidor
- **Lucide React** - Icones

### Web3 Integration
- **Ethers.js / Viem** - Comunicacao blockchain
- **Wagmi** - Hooks React para Web3
- **RainbowKit** - Conexao de carteiras
- **MetaMask / WalletConnect** - Provedores de carteira

### Blockchain
- **Solidity ^0.8.0** - Smart Contracts
- **ERC-721** - Padrao NFT para contratos
- **Polygon (MATIC)** - Rede principal (baixo custo de gas)
- **Polygon Mumbai** - Testnet

### Armazenamento
- **IPFS (Pinata)** - Documentos e midia de vistoria
- **Google Sheets/Firebase** - Dados off-chain (prototipagem)

---

## Stack de APIs Brasileiras

### Pagamentos e Split
| API | Funcao |
|-----|--------|
| **Asaas** | PIX, Boleto, Cartao com Split automatico 85/5/5/5 |
| **Stark Bank** | Alternativa para alto volume transacional |
| **BRZ (Transfero)** | Stablecoin pareada ao Real para evitar volatilidade |

### Identidade e Credito (KYC)
| API | Funcao |
|-----|--------|
| **Unico ID (Check)** | Biometria facial e validacao de documentos (RG/CNH) |
| **Serasa Experian** | Score de credito, negativacoes e protestos |
| **Open Finance (Transfeera/Quanto)** | Comprovacao de renda via extrato bancario |
| **ClearSale** | Analise de fraude em perfis de locatarios |

### Assinatura Digital
| API | Funcao |
|-----|--------|
| **ZapSign** | Assinatura via WhatsApp com validade juridica |
| **Clicksign** | Alternativa com certificado digital ICP-Brasil |

### Dados Imobiliarios
| API | Funcao |
|-----|--------|
| **CERC** | Central de Recebiveis para registro de garantias |
| **OpenNodes** | Busca de dados cartoriais |

### Notificacoes
| API | Funcao |
|-----|--------|
| **Twilio / Z-API** | WhatsApp para cobrancas e avisos |

---

## Arquitetura da Ponte (Bridge)

```
┌─────────────┐    Webhook    ┌──────────────────┐    Transacao    ┌─────────────┐
│  PIX/Boleto │ ───────────── │  Cloud Function  │ ─────────────── │  Blockchain │
│   (Asaas)   │               │   (Node.js)      │                 │  (Polygon)  │
└─────────────┘               └──────────────────┘                 └─────────────┘
       │                              │                                   │
       │                              │                                   │
       ▼                              ▼                                   ▼
   Locatario                   Split 85/5/5/5                      NFT Contrato
   paga aluguel              Locador/Seguradora                   Status: Ativo
                             Plataforma/Garantidor
```

### Fluxo de Pagamento
1. **Gatilho**: Locatario paga aluguel via PIX/Boleto
2. **Webhook**: Asaas envia confirmacao para Cloud Function
3. **Execucao**: Cloud Function assina transacao com chave da plataforma
4. **Split**: Smart Contract distribui 85/5/5/5 automaticamente
5. **Confirmacao**: Blockchain confirma e App atualiza status

---

## Arquitetura do Sistema

```
[Usuario] <-> [React Frontend] <-> [Wagmi/Ethers] <-> [Blockchain (NFTs)]
                                         ^
                                         |
                                  [IPFS Storage]
                             (Fotos/Vistoria/Documentos)
```

### Estrutura de Pastas

```
src/
├── components/
│   ├── dashboards/
│   │   ├── admin-dashboard.tsx      # Governanca, Disputas, DIMOB, Integracoes
│   │   ├── landlord-dashboard.tsx   # Estilo "Home Broker"
│   │   ├── tenant-dashboard.tsx     # Estilo "Airbnb/App-First"
│   │   └── guarantor-dashboard.tsx  # Gestao de garantias
│   ├── pitch-deck.tsx               # Apresentacao para investidores
│   └── wallet-connector.tsx         # Conexao Web3
├── hooks/
│   ├── use-wallet-connection.ts     # Gerenciamento de carteira
│   ├── use-pay-rent.ts              # Pagamento blockchain
│   ├── use-create-rental.ts         # Mintagem de NFT
│   └── use-payment-integration.ts   # Integracao PIX/Boleto com Split
├── lib/
│   ├── bridge/
│   │   ├── cloud-functions.ts       # Cloud Functions para Webhook -> Blockchain
│   │   ├── asaas-service.ts         # API Asaas (Pagamentos + Split)
│   │   ├── kyc-service.ts           # APIs KYC (Unico ID, Serasa, Open Finance)
│   │   ├── zapsign-service.ts       # API ZapSign (Assinatura Digital)
│   │   ├── webhook-handler.ts       # Gerenciador de Webhooks
│   │   └── index.ts                 # Exports
│   ├── web3/
│   │   ├── vinculo-contract-abi.ts  # ABI do Smart Contract
│   │   ├── types.ts                 # Tipos TypeScript
│   │   └── index.ts                 # Exports
│   ├── blockchain-service.ts        # Servicos blockchain
│   └── risk-automation.ts           # Analise de risco com IA
└── routes/
    └── index.tsx                    # Pagina principal
```

---

## Smart Contract

### Funcoes Principais

```solidity
// Cria o NFT do contrato (Minting)
function createRental(
    address _tenant,
    address _guarantor,
    address _insurer,
    uint256 _amount,
    uint256 _duration,
    string _collateralPropertyId
) public returns (uint256 tokenId);

// Pagamento com Split Automatico 85/5/5/5
function payRent(uint256 _tokenId) public payable;

// Bloqueia imovel do garantidor
function lockCollateral(uint256 _tokenId, string _propertyId) public;

// Libera garantia apos fim do contrato
function unlockCollateral(uint256 _tokenId) public;
```

### Eventos

```solidity
event RentalCreated(uint256 indexed tokenId, address landlord, address tenant);
event PaymentReceived(uint256 indexed tokenId, uint256 amount, uint256 timestamp);
event CollateralLocked(uint256 indexed tokenId, address guarantor, string propertyId);
event CollateralUnlocked(uint256 indexed tokenId);
event RentalTerminated(uint256 indexed tokenId, string reason);
```

---

## Conformidade Legal

### Lei do Inquilinato (8.245/91)
- Clausulas de reajuste (IPCA) automatizadas
- Multa por atraso (10%) via Smart Contract
- Aviso previo de 30 dias codificado
- Despejo conforme legislacao

### LGPD (Lei Geral de Protecao de Dados)
- Criptografia de dados sensiveis
- Anonimizacao de registros pessoais apos ciclo contratual
- Consentimento explicito para KYC

### DIMOB (Receita Federal)
- Exportacao automatica de XML
- Dados de contratos, locadores e locatarios
- Valores recebidos e pagos

---

## Instalacao

```bash
# Clone o repositorio
git clone https://github.com/seu-usuario/vinculo-io.git

# Instale as dependencias
cd vinculo-io
npm install

# Execute em desenvolvimento
npm run dev

# Validacao (TypeScript + ESLint)
npm run check:safe
```

---

## Comandos Disponiveis

| Comando | Descricao |
|---------|-----------|
| `npm run dev` | Inicia servidor de desenvolvimento |
| `npm run build` | Build de producao |
| `npm run check:safe` | Validacao TypeScript + ESLint |
| `npm run format` | Formata codigo com Biome |

---

## Roadmap

### Fase 1: Fundacao (Concluido)
- [x] Definicao da Arquitetura de Dados
- [x] Estruturacao dos Smart Contracts basicos
- [x] Dashboards completos (Locador, Locatario, Garantidor, Admin)
- [x] Integracao Web3 (Wallet, Pagamento, NFT)
- [x] Sistema de Disputas e Arbitragem Multi-Sig
- [x] Pitch Deck interativo para investidores

### Fase 2: Ponte Real-Digital (Concluido)
- [x] Cloud Functions para Webhook -> Blockchain
- [x] Integracao Asaas (PIX, Boleto, Split automatico)
- [x] Integracao KYC (Unico ID, Serasa, Open Finance)
- [x] Integracao Assinatura Digital (ZapSign)
- [x] Dashboard de Integracoes no Admin
- [x] Hook de pagamento com Split 85/5/5/5

### Fase 3: Producao (Em andamento)
- [ ] Implementacao do Oraculo Chainlink (BRL/Stablecoin)
- [ ] App Mobile (React Native) para Vistoria In-loco
- [ ] Integracao com o Drex (Real Digital)
- [ ] Deploy Smart Contract na Polygon Mainnet
- [ ] Parceria com Seguradora (Porto Seguro ou Too Seguros)
- [ ] Sandbox SUSEP para operacao como Insurtech

---

## Esquema de Dados (Google Sheets/Firebase)

### Tabela: Users
| Campo | Tipo | Descricao |
|-------|------|-----------|
| ID_User | Key | Identificador unico |
| Nome_Completo | String | Nome do usuario |
| CPF_CNPJ | String | Documento |
| Email | String | Email |
| Tipo_Perfil | Enum | Locador, Locatario, Garantidor, Seguradora, Admin |
| Wallet_Address | String | Endereco blockchain |
| Status_KYC | Enum | Pendente, Aprovado, Rejeitado |

### Tabela: Properties
| Campo | Tipo | Descricao |
|-------|------|-----------|
| ID_Imovel | Key | Identificador unico |
| ID_Owner | Ref(Users) | Proprietario |
| Endereco_Completo | String | Endereco |
| Valor_Aluguel | Decimal | Valor mensal |
| Status_NFT | Enum | Ativo, Pendente, Inativo |
| Link_Fotos_IPFS | String | CID do IPFS |

### Tabela: Contracts
| Campo | Tipo | Descricao |
|-------|------|-----------|
| ID_Contrato | Key | Identificador unico |
| ID_Locatario | Ref(Users) | Inquilino |
| ID_Locador | Ref(Users) | Proprietario |
| ID_Imovel | Ref(Properties) | Imovel |
| ID_Garantidor | Ref(Users) | Garantidor |
| Hash_NFT | String | Token ID blockchain |
| Status_Contrato | Enum | Ativo, Encerrado, Disputa |

### Tabela: Payments
| Campo | Tipo | Descricao |
|-------|------|-----------|
| ID_Transacao | Key | Identificador unico |
| ID_Contrato | Ref(Contracts) | Contrato |
| Valor_Pago | Decimal | Valor |
| Status_Pagamento | Enum | Confirmado, Pendente, Atrasado |
| Comprovante_Hash | String | Hash blockchain |

---

## Contribuindo

1. Fork o repositorio
2. Crie uma branch (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudancas (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

---

## Licenca

Este projeto esta sob a licenca MIT. Veja o arquivo [LICENSE](LICENSE) para detalhes.

---

## Contato

- **Projeto:** Vinculo.io
- **Email:** contato@vinculo.io
- **GitHub:** [github.com/vinculo-io](https://github.com/vinculo-io)

---

> **Desenvolvido com React + TypeScript + Tailwind CSS + Blockchain**
>
> A locacao inteligente, garantida por quem voce confia e protegida por tecnologia.
