/**
 * Deploy Script for Vinculo.io Smart Contracts
 *
 * Usage:
 *   npx hardhat run scripts/deploy.cjs --network polygonAmoy
 *   npx hardhat run scripts/deploy.cjs --network polygon
 */

const hre = require("hardhat");

async function main() {
  console.log("🚀 Starting Vinculo.io Smart Contracts Deployment...\n");

  const [deployer] = await hre.ethers.getSigners();
  const balance = await hre.ethers.provider.getBalance(deployer.address);

  console.log("📋 Deployment Configuration:");
  console.log("   Network:", hre.network.name);
  console.log("   Deployer:", deployer.address);
  console.log("   Balance:", hre.ethers.formatEther(balance), "MATIC\n");

  // Platform wallet - em producao, usar endereco real
  const platformWallet = process.env.PLATFORM_WALLET || deployer.address;
  console.log("   Platform Wallet:", platformWallet);
  console.log("");

  // ========================================
  // 1. Deploy VinculoContract (Main Contract)
  // ========================================
  console.log("1️⃣  Deploying VinculoContract...");

  const VinculoContract = await hre.ethers.getContractFactory("VinculoContract");
  const vinculoContract = await VinculoContract.deploy(platformWallet);
  await vinculoContract.waitForDeployment();

  const vinculoAddress = await vinculoContract.getAddress();
  console.log("   ✅ VinculoContract deployed to:", vinculoAddress);
  console.log("");

  // ========================================
  // 2. Deploy PropertyCollateral
  // ========================================
  console.log("2️⃣  Deploying PropertyCollateral...");

  const PropertyCollateral = await hre.ethers.getContractFactory("PropertyCollateral");
  const propertyCollateral = await PropertyCollateral.deploy();
  await propertyCollateral.waitForDeployment();

  const collateralAddress = await propertyCollateral.getAddress();
  console.log("   ✅ PropertyCollateral deployed to:", collateralAddress);
  console.log("");

  // ========================================
  // 3. Deploy VinculoGovernance
  // ========================================
  console.log("3️⃣  Deploying VinculoGovernance...");

  const VinculoGovernance = await hre.ethers.getContractFactory("VinculoGovernance");
  const vinculoGovernance = await VinculoGovernance.deploy();
  await vinculoGovernance.waitForDeployment();

  const governanceAddress = await vinculoGovernance.getAddress();
  console.log("   ✅ VinculoGovernance deployed to:", governanceAddress);
  console.log("");

  // ========================================
  // 4. Configure Contracts
  // ========================================
  console.log("4️⃣  Configuring contract relationships...");

  // Link PropertyCollateral to VinculoContract
  const setVinculoTx = await propertyCollateral.setVinculoContract(vinculoAddress);
  await setVinculoTx.wait();
  console.log("   ✅ PropertyCollateral linked to VinculoContract");
  console.log("");

  // ========================================
  // 5. Summary
  // ========================================
  console.log("═══════════════════════════════════════════════════════════");
  console.log("✨ DEPLOYMENT COMPLETE!");
  console.log("═══════════════════════════════════════════════════════════");
  console.log("");
  console.log("📝 Contract Addresses:");
  console.log("   VinculoContract:    ", vinculoAddress);
  console.log("   PropertyCollateral: ", collateralAddress);
  console.log("   VinculoGovernance:  ", governanceAddress);
  console.log("");
  console.log("🔗 Platform Wallet:", platformWallet);
  console.log("💰 Split: 85% Landlord | 5% Insurer | 5% Platform | 5% Guarantor");
  console.log("");

  // ========================================
  // 6. Verification Commands
  // ========================================
  console.log("📋 To verify contracts on PolygonScan, run:");
  console.log("");
  console.log(`   npx hardhat verify --network ${hre.network.name} ${vinculoAddress} "${platformWallet}"`);
  console.log(`   npx hardhat verify --network ${hre.network.name} ${collateralAddress}`);
  console.log(`   npx hardhat verify --network ${hre.network.name} ${governanceAddress}`);
  console.log("");

  // ========================================
  // 7. Export for Frontend
  // ========================================
  const deploymentInfo = {
    network: hre.network.name,
    chainId: hre.network.config.chainId,
    deployer: deployer.address,
    platformWallet: platformWallet,
    timestamp: new Date().toISOString(),
    contracts: {
      VinculoContract: {
        address: vinculoAddress,
        name: "Vinculo Rental Contract",
        symbol: "VINCULO"
      },
      PropertyCollateral: {
        address: collateralAddress,
        name: "Vinculo Property Collateral",
        symbol: "VPROP"
      },
      VinculoGovernance: {
        address: governanceAddress
      }
    }
  };

  // Save deployment info
  const fs = require("fs");
  const path = require("path");

  const deploymentsDir = path.join(__dirname, "..", "deployments");
  if (!fs.existsSync(deploymentsDir)) {
    fs.mkdirSync(deploymentsDir, { recursive: true });
  }

  const filename = `${hre.network.name}-${Date.now()}.json`;
  fs.writeFileSync(
    path.join(deploymentsDir, filename),
    JSON.stringify(deploymentInfo, null, 2)
  );

  // Also save as "latest" for easy access
  fs.writeFileSync(
    path.join(deploymentsDir, `${hre.network.name}-latest.json`),
    JSON.stringify(deploymentInfo, null, 2)
  );

  console.log(`💾 Deployment info saved to: deployments/${filename}`);
  console.log("");
  console.log("═══════════════════════════════════════════════════════════");

  return deploymentInfo;
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Deployment failed:", error);
    process.exit(1);
  });
