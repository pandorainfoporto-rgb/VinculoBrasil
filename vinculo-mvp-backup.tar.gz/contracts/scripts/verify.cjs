/**
 * Verification Script for Vinculo.io Smart Contracts
 *
 * Automatically verifies all deployed contracts on PolygonScan.
 *
 * Usage:
 *   npx hardhat run scripts/verify.cjs --network polygonAmoy
 *   npx hardhat run scripts/verify.cjs --network polygon
 */

const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  console.log("🔍 Starting Contract Verification on PolygonScan...\n");

  const network = hre.network.name;
  console.log("📋 Network:", network);
  console.log("");

  // Load deployment info
  const deploymentsDir = path.join(__dirname, "..", "deployments");
  const deploymentFile = path.join(deploymentsDir, `${network}-latest.json`);

  if (!fs.existsSync(deploymentFile)) {
    console.error(`❌ No deployment found for network: ${network}`);
    console.error(`   Expected file: ${deploymentFile}`);
    console.error("");
    console.error("   Run the deploy script first:");
    console.error(`   npx hardhat run scripts/deploy.cjs --network ${network}`);
    process.exit(1);
  }

  const deployment = JSON.parse(fs.readFileSync(deploymentFile, "utf-8"));
  console.log("📂 Loaded deployment from:", deploymentFile);
  console.log("   Deployed at:", deployment.timestamp);
  console.log("");

  const results = {
    success: [],
    failed: [],
    skipped: []
  };

  // ========================================
  // 1. Verify VinculoContract
  // ========================================
  console.log("═══════════════════════════════════════════════════════════");
  console.log("1️⃣  Verifying VinculoContract...");
  console.log("   Address:", deployment.contracts.VinculoContract.address);
  console.log("   Constructor Args: [\"" + deployment.platformWallet + "\"]");
  console.log("");

  try {
    await hre.run("verify:verify", {
      address: deployment.contracts.VinculoContract.address,
      constructorArguments: [deployment.platformWallet],
      contract: "contracts/src/VinculoContract.sol:VinculoContract"
    });
    console.log("   ✅ VinculoContract verified successfully!");
    results.success.push("VinculoContract");
  } catch (error) {
    if (error.message.includes("Already Verified")) {
      console.log("   ⚠️  VinculoContract already verified");
      results.skipped.push("VinculoContract");
    } else {
      console.log("   ❌ VinculoContract verification failed:", error.message);
      results.failed.push({ name: "VinculoContract", error: error.message });
    }
  }
  console.log("");

  // ========================================
  // 2. Verify PropertyCollateral
  // ========================================
  console.log("═══════════════════════════════════════════════════════════");
  console.log("2️⃣  Verifying PropertyCollateral...");
  console.log("   Address:", deployment.contracts.PropertyCollateral.address);
  console.log("   Constructor Args: []");
  console.log("");

  try {
    await hre.run("verify:verify", {
      address: deployment.contracts.PropertyCollateral.address,
      constructorArguments: [],
      contract: "contracts/src/PropertyCollateral.sol:PropertyCollateral"
    });
    console.log("   ✅ PropertyCollateral verified successfully!");
    results.success.push("PropertyCollateral");
  } catch (error) {
    if (error.message.includes("Already Verified")) {
      console.log("   ⚠️  PropertyCollateral already verified");
      results.skipped.push("PropertyCollateral");
    } else {
      console.log("   ❌ PropertyCollateral verification failed:", error.message);
      results.failed.push({ name: "PropertyCollateral", error: error.message });
    }
  }
  console.log("");

  // ========================================
  // 3. Verify VinculoGovernance
  // ========================================
  console.log("═══════════════════════════════════════════════════════════");
  console.log("3️⃣  Verifying VinculoGovernance...");
  console.log("   Address:", deployment.contracts.VinculoGovernance.address);
  console.log("   Constructor Args: []");
  console.log("");

  try {
    await hre.run("verify:verify", {
      address: deployment.contracts.VinculoGovernance.address,
      constructorArguments: [],
      contract: "contracts/src/VinculoGovernance.sol:VinculoGovernance"
    });
    console.log("   ✅ VinculoGovernance verified successfully!");
    results.success.push("VinculoGovernance");
  } catch (error) {
    if (error.message.includes("Already Verified")) {
      console.log("   ⚠️  VinculoGovernance already verified");
      results.skipped.push("VinculoGovernance");
    } else {
      console.log("   ❌ VinculoGovernance verification failed:", error.message);
      results.failed.push({ name: "VinculoGovernance", error: error.message });
    }
  }
  console.log("");

  // ========================================
  // Summary
  // ========================================
  console.log("═══════════════════════════════════════════════════════════");
  console.log("📊 VERIFICATION SUMMARY");
  console.log("═══════════════════════════════════════════════════════════");
  console.log("");

  if (results.success.length > 0) {
    console.log("✅ Successfully Verified:");
    results.success.forEach(name => console.log(`   - ${name}`));
    console.log("");
  }

  if (results.skipped.length > 0) {
    console.log("⚠️  Already Verified (Skipped):");
    results.skipped.forEach(name => console.log(`   - ${name}`));
    console.log("");
  }

  if (results.failed.length > 0) {
    console.log("❌ Failed to Verify:");
    results.failed.forEach(item => {
      console.log(`   - ${item.name}: ${item.error}`);
    });
    console.log("");
  }

  // ========================================
  // PolygonScan Links
  // ========================================
  const explorerBase = network === "polygon"
    ? "https://polygonscan.com"
    : "https://amoy.polygonscan.com";

  console.log("═══════════════════════════════════════════════════════════");
  console.log("🔗 Contract Links on PolygonScan:");
  console.log("");
  console.log(`   VinculoContract:`);
  console.log(`   ${explorerBase}/address/${deployment.contracts.VinculoContract.address}#code`);
  console.log("");
  console.log(`   PropertyCollateral:`);
  console.log(`   ${explorerBase}/address/${deployment.contracts.PropertyCollateral.address}#code`);
  console.log("");
  console.log(`   VinculoGovernance:`);
  console.log(`   ${explorerBase}/address/${deployment.contracts.VinculoGovernance.address}#code`);
  console.log("");
  console.log("═══════════════════════════════════════════════════════════");

  // Save verification results
  const verificationResults = {
    network,
    timestamp: new Date().toISOString(),
    deployment: deploymentFile,
    results,
    links: {
      VinculoContract: `${explorerBase}/address/${deployment.contracts.VinculoContract.address}#code`,
      PropertyCollateral: `${explorerBase}/address/${deployment.contracts.PropertyCollateral.address}#code`,
      VinculoGovernance: `${explorerBase}/address/${deployment.contracts.VinculoGovernance.address}#code`
    }
  };

  const verificationFile = path.join(deploymentsDir, `${network}-verification.json`);
  fs.writeFileSync(verificationFile, JSON.stringify(verificationResults, null, 2));
  console.log(`💾 Verification results saved to: ${verificationFile}`);
  console.log("");

  return results;
}

main()
  .then((results) => {
    if (results.failed.length > 0) {
      process.exit(1);
    }
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Verification script failed:", error);
    process.exit(1);
  });
