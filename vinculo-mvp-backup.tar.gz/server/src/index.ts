// ============================================
// VINCULO BRASIL - SERVER ENTRY POINT
// ============================================

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { pinoHttp } from 'pino-http';
import { config } from './config/index.js';
import { prisma } from './lib/prisma.js';
import { redis } from './lib/redis.js';
import { logger } from './lib/logger.js';
import { errorHandler } from './middleware/error-handler.js';
import { authMiddleware } from './middleware/auth.js';

// Routes
import authRoutes from './routes/auth.js';
import setupRoutes from './routes/setup.js';
import usersRoutes from './routes/users.js';
import propertiesRoutes from './routes/properties.js';
import contractsRoutes from './routes/contracts.js';
import paymentsRoutes from './routes/payments.js';
import leadsRoutes from './routes/leads.js';
import dealsRoutes from './routes/deals.js';
import ticketsRoutes from './routes/tickets.js';
import webhooksRoutes from './routes/webhooks.js';
import blockchainRoutes from './routes/blockchain.js';
import reportsRoutes from './routes/reports.js';
import marketplaceRoutes from './routes/marketplace.js';
import vouchersRoutes from './routes/vouchers.js';

// Workers
import { initWorkers } from './workers/index.js';

const app = express();

// ============================================
// MIDDLEWARE
// ============================================

// Security
app.use(helmet({
  contentSecurityPolicy: false, // Desabilitado para SPA
}));

// CORS
app.use(cors({
  origin: config.corsOrigin,
  credentials: true,
}));

// Compression
app.use(compression());

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Cookies
app.use(cookieParser());

// Logging
app.use(pinoHttp({
  logger,
  autoLogging: {
    ignore: (req) => req.url?.includes('/health') ?? false,
  },
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // 100 requests por janela
  message: { error: 'Too many requests, please try again later.' },
  skip: (req) => req.url?.includes('/webhooks') ?? false, // Skip para webhooks
});
app.use('/api', limiter);

// ============================================
// HEALTH CHECK
// ============================================

app.get('/health', async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    await redis.ping();
    res.json({ status: 'healthy', timestamp: new Date().toISOString() });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy', error: String(error) });
  }
});

// ============================================
// API ROUTES
// ============================================

// Setup (sem autenticacao - primeira execucao)
app.use('/api/setup', setupRoutes);

// Auth
app.use('/api/auth', authRoutes);

// Webhooks (sem autenticacao, validados internamente)
app.use('/api/webhooks', webhooksRoutes);

// Rotas protegidas
app.use('/api/users', authMiddleware, usersRoutes);
app.use('/api/properties', authMiddleware, propertiesRoutes);
app.use('/api/contracts', authMiddleware, contractsRoutes);
app.use('/api/payments', authMiddleware, paymentsRoutes);
app.use('/api/leads', authMiddleware, leadsRoutes);
app.use('/api/deals', authMiddleware, dealsRoutes);
app.use('/api/tickets', authMiddleware, ticketsRoutes);
app.use('/api/blockchain', authMiddleware, blockchainRoutes);
app.use('/api/reports', authMiddleware, reportsRoutes);
app.use('/api/marketplace', authMiddleware, marketplaceRoutes);
app.use('/api/vouchers', authMiddleware, vouchersRoutes);

// ============================================
// STATIC FILES (Frontend SPA)
// ============================================

app.use(express.static('public'));

// SPA fallback
app.get('*', (_req, res) => {
  res.sendFile('index.html', { root: 'public' });
});

// ============================================
// ERROR HANDLER
// ============================================

app.use(errorHandler);

// ============================================
// SERVER STARTUP
// ============================================

async function bootstrap() {
  try {
    // Verificar conexao com banco
    console.log('Connecting to database...');
    await prisma.$connect();
    console.log('Database connected');
    logger.info('Database connected');

    // Verificar conexao com Redis (OPCIONAL)
    try {
      console.log('Connecting to Redis...');
      await redis.ping();
      console.log('Redis connected');
      logger.info('Redis connected');
    } catch (redisError) {
      console.log('Redis connection failed (optional):', redisError instanceof Error ? redisError.message : String(redisError));
      logger.warn('Redis not available, running without queue workers');
    }

    // Inicializar workers (apenas se Redis estiver disponível)
    try {
      await initWorkers();
      console.log('Workers initialized');
      logger.info('Workers initialized');
    } catch (workerError) {
      console.log('Workers init failed (optional):', workerError instanceof Error ? workerError.message : String(workerError));
      logger.warn('Workers not initialized');
    }

    // Iniciar servidor
    const server = app.listen(config.port, config.host, () => {
      logger.info(`Server running on http://${config.host}:${config.port}`);
      logger.info(`Environment: ${config.nodeEnv}`);
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      logger.info(`${signal} received, shutting down gracefully...`);

      server.close(async () => {
        logger.info('HTTP server closed');

        await prisma.$disconnect();
        logger.info('Database disconnected');

        await redis.quit();
        logger.info('Redis disconnected');

        process.exit(0);
      });

      // Force close after 30s
      setTimeout(() => {
        logger.error('Could not close connections in time, forcefully shutting down');
        process.exit(1);
      }, 30000);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  } catch (error: any) {
    console.log("🔥 ERRO FATAL DETECTADO 🔥");
    console.log("---------------------------------------------------");
    // Imprime o erro como string simples para garantir que apareça no log
    console.log(error instanceof Error ? error.message : String(error));
    console.log("STACK TRACE:");
    console.log(error instanceof Error ? error.stack : "Sem stack trace");
    console.log("---------------------------------------------------");
    process.exit(1);
  }
}

bootstrap();

export { app };
