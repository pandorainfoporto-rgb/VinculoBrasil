/**
 * Pinata Service - IPFS Upload para VinculoBrasil
 *
 * Responsável por:
 * - Upload de fotos de vistoria para IPFS
 * - Geração de metadata JSON
 * - Pinning permanente dos arquivos
 * - Retorno do IPFS hash (CID)
 */

import axios, { type AxiosInstance } from 'axios';
import FormData from 'form-data';
import * as fs from 'fs';
import { logger } from './logger.js';

interface PinataConfig {
  apiKey: string;
  secretApiKey: string;
  jwt?: string;
}

interface PinataResponse {
  IpfsHash: string;
  PinSize: number;
  Timestamp: string;
}

interface InspectionMetadata {
  name: string;
  description: string;
  image: string; // IPFS hash da imagem principal
  external_url?: string;
  attributes: Array<{
    trait_type: string;
    value: string | number;
  }>;
  properties: {
    propertyAddress: string;
    inspectionType: 'ENTRADA' | 'SAIDA' | 'CONTRATO';
    inspectionDate: string;
    inspector: string;
    photos: string[]; // Array de IPFS hashes
    report?: string; // IPFS hash do PDF do laudo
  };
}

export class PinataService {
  private client: AxiosInstance;
  private config: PinataConfig;
  private readonly GATEWAY_URL = 'https://gateway.pinata.cloud/ipfs/';

  constructor(config?: Partial<PinataConfig>) {
    // Carregar config das variáveis de ambiente
    this.config = {
      apiKey: config?.apiKey || process.env.PINATA_API_KEY || '',
      secretApiKey: config?.secretApiKey || process.env.PINATA_SECRET_KEY || '',
      jwt: config?.jwt || process.env.PINATA_JWT || '',
    };

    if (!this.config.apiKey || !this.config.secretApiKey) {
      logger.warn('Pinata credentials not configured. IPFS uploads will fail.');
    }

    // Cliente HTTP para Pinata API
    this.client = axios.create({
      baseURL: 'https://api.pinata.cloud',
      headers: this.config.jwt
        ? {
            Authorization: `Bearer ${this.config.jwt}`,
          }
        : {
            pinata_api_key: this.config.apiKey,
            pinata_secret_api_key: this.config.secretApiKey,
          },
    });
  }

  /**
   * Testar conexão com Pinata
   */
  async testAuthentication(): Promise<boolean> {
    try {
      const response = await this.client.get('/data/testAuthentication');
      logger.info('Pinata authentication successful', response.data);
      return true;
    } catch (error) {
      logger.error('Pinata authentication failed', error);
      return false;
    }
  }

  /**
   * Upload de arquivo (imagem, PDF, etc) para IPFS
   */
  async uploadFile(
    filePath: string,
    metadata?: { name?: string; keyvalues?: Record<string, string> }
  ): Promise<string> {
    try {
      const formData = new FormData();
      const file = fs.createReadStream(filePath);

      formData.append('file', file);

      if (metadata) {
        const pinataMetadata = {
          name: metadata.name || filePath.split('/').pop(),
          keyvalues: metadata.keyvalues || {},
        };
        formData.append('pinataMetadata', JSON.stringify(pinataMetadata));
      }

      const response = await this.client.post<PinataResponse>(
        '/pinning/pinFileToIPFS',
        formData,
        {
          headers: formData.getHeaders(),
          maxBodyLength: Infinity,
        }
      );

      const ipfsHash = response.data.IpfsHash;
      logger.info(`File uploaded to IPFS: ${ipfsHash}`, {
        file: filePath,
        size: response.data.PinSize,
      });

      return ipfsHash;
    } catch (error) {
      logger.error('Failed to upload file to Pinata', error);
      throw new Error(`Pinata upload failed: ${error}`);
    }
  }

  /**
   * Upload de Buffer (para imagens em memória)
   */
  async uploadBuffer(
    buffer: Buffer,
    filename: string,
    metadata?: { keyvalues?: Record<string, string> }
  ): Promise<string> {
    try {
      const formData = new FormData();
      formData.append('file', buffer, filename);

      if (metadata) {
        const pinataMetadata = {
          name: filename,
          keyvalues: metadata.keyvalues || {},
        };
        formData.append('pinataMetadata', JSON.stringify(pinataMetadata));
      }

      const response = await this.client.post<PinataResponse>(
        '/pinning/pinFileToIPFS',
        formData,
        {
          headers: formData.getHeaders(),
          maxBodyLength: Infinity,
        }
      );

      return response.data.IpfsHash;
    } catch (error) {
      logger.error('Failed to upload buffer to Pinata', error);
      throw new Error(`Pinata buffer upload failed: ${error}`);
    }
  }

  /**
   * Upload de JSON (metadata do NFT)
   */
  async uploadJSON(data: object, name?: string): Promise<string> {
    try {
      const response = await this.client.post<PinataResponse>('/pinning/pinJSONToIPFS', {
        pinataContent: data,
        pinataMetadata: {
          name: name || 'metadata.json',
        },
      });

      const ipfsHash = response.data.IpfsHash;
      logger.info(`JSON uploaded to IPFS: ${ipfsHash}`, { name });

      return ipfsHash;
    } catch (error) {
      logger.error('Failed to upload JSON to Pinata', error);
      throw new Error(`Pinata JSON upload failed: ${error}`);
    }
  }

  /**
   * Upload completo de uma vistoria (fotos + metadata)
   *
   * Fluxo:
   * 1. Upload de todas as fotos
   * 2. Montagem do JSON de metadata
   * 3. Upload do metadata JSON
   * 4. Retorno do IPFS hash final (que vai no NFT)
   */
  async uploadInspection(params: {
    photos: Array<{ path: string; description?: string }>;
    propertyAddress: string;
    inspectionType: 'ENTRADA' | 'SAIDA' | 'CONTRATO';
    inspector: string;
    notes?: string;
  }): Promise<{ metadataHash: string; photosHashes: string[] }> {
    try {
      logger.info('Starting inspection upload to IPFS', {
        propertyAddress: params.propertyAddress,
        photosCount: params.photos.length,
      });

      // 1. Upload de todas as fotos
      const photosHashes: string[] = [];

      for (const photo of params.photos) {
        const hash = await this.uploadFile(photo.path, {
          name: photo.description || photo.path.split('/').pop(),
          keyvalues: {
            type: 'inspection-photo',
            property: params.propertyAddress,
          },
        });
        photosHashes.push(hash);
      }

      logger.info(`Uploaded ${photosHashes.length} photos to IPFS`);

      // 2. Montar metadata JSON (formato ERC-721)
      const metadata: InspectionMetadata = {
        name: `${params.propertyAddress} - ${params.inspectionType}`,
        description:
          params.notes ||
          `Vistoria de ${params.inspectionType.toLowerCase()} realizada em ${new Date().toLocaleDateString('pt-BR')}`,
        image: `ipfs://${photosHashes[0]}`, // Primeira foto como thumbnail
        external_url: `https://vinculobrasil.com.br/inspections/${params.propertyAddress}`,
        attributes: [
          {
            trait_type: 'Property Address',
            value: params.propertyAddress,
          },
          {
            trait_type: 'Inspection Type',
            value: params.inspectionType,
          },
          {
            trait_type: 'Inspector',
            value: params.inspector,
          },
          {
            trait_type: 'Photos Count',
            value: photosHashes.length,
          },
          {
            trait_type: 'Inspection Date',
            value: new Date().toISOString(),
          },
        ],
        properties: {
          propertyAddress: params.propertyAddress,
          inspectionType: params.inspectionType,
          inspectionDate: new Date().toISOString(),
          inspector: params.inspector,
          photos: photosHashes,
        },
      };

      // 3. Upload do metadata JSON
      const metadataHash = await this.uploadJSON(
        metadata,
        `${params.propertyAddress}-${params.inspectionType}-metadata.json`
      );

      logger.info('Inspection metadata uploaded successfully', {
        metadataHash,
        photosCount: photosHashes.length,
      });

      return {
        metadataHash,
        photosHashes,
      };
    } catch (error) {
      logger.error('Failed to upload inspection to IPFS', error);
      throw error;
    }
  }

  /**
   * Retorna URL pública do IPFS (via gateway Pinata)
   */
  getPublicUrl(ipfsHash: string): string {
    return `${this.GATEWAY_URL}${ipfsHash}`;
  }

  /**
   * Unpinning (remover arquivo do IPFS)
   * CUIDADO: Use apenas se tiver certeza!
   */
  async unpin(ipfsHash: string): Promise<void> {
    try {
      await this.client.delete(`/pinning/unpin/${ipfsHash}`);
      logger.info(`Unpinned ${ipfsHash} from IPFS`);
    } catch (error) {
      logger.error(`Failed to unpin ${ipfsHash}`, error);
      throw error;
    }
  }

  /**
   * Listar todos os pins da conta
   */
  async listPins(filters?: {
    status?: 'pinned' | 'unpinned';
    metadata?: Record<string, string>;
  }): Promise<any[]> {
    try {
      const params = new URLSearchParams();

      if (filters?.status) {
        params.append('status', filters.status);
      }

      if (filters?.metadata) {
        Object.entries(filters.metadata).forEach(([key, value]) => {
          params.append(`metadata[keyvalues][${key}]`, value);
        });
      }

      const response = await this.client.get('/data/pinList', { params });
      return response.data.rows;
    } catch (error) {
      logger.error('Failed to list pins', error);
      throw error;
    }
  }
}

// Export singleton instance
export const pinataService = new PinataService();
