// ============================================
// WEBHOOKS ROUTES (Asaas, Transfero, etc.)
// ============================================

import { Router } from 'express';
import crypto from 'crypto';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { redis } from '../lib/redis.js';

const router = Router();

// Asaas Webhook
router.post('/asaas', async (req, res) => {
  try {
    const event = req.body.event;
    const payment = req.body.payment;

    // Log webhook
    await prisma.webhookLog.create({
      data: {
        provider: 'asaas',
        event,
        payload: req.body,
      },
    });

    logger.info(`Asaas webhook: ${event}`);

    switch (event) {
      case 'PAYMENT_CONFIRMED':
      case 'PAYMENT_RECEIVED': {
        // Buscar pagamento pelo externalId
        const dbPayment = await prisma.payment.findFirst({
          where: { gatewayId: payment.id },
        });

        if (dbPayment) {
          await prisma.payment.update({
            where: { id: dbPayment.id },
            data: {
              status: 'PAID',
              paidAt: new Date(),
            },
          });

          // Adicionar job para processar split
          await redis.lpush('payment:split', JSON.stringify({
            paymentId: dbPayment.id,
            amount: payment.value,
          }));
        }
        break;
      }

      case 'PAYMENT_OVERDUE': {
        const dbPayment = await prisma.payment.findFirst({
          where: { gatewayId: payment.id },
        });

        if (dbPayment) {
          await prisma.payment.update({
            where: { id: dbPayment.id },
            data: { status: 'OVERDUE' },
          });
        }
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error('Asaas webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Transfero Webhook
router.post('/transfero', async (req, res) => {
  try {
    const { type, data } = req.body;

    await prisma.webhookLog.create({
      data: {
        provider: 'transfero',
        event: type,
        payload: req.body,
      },
    });

    logger.info(`Transfero webhook: ${type}`);

    switch (type) {
      case 'swap.completed': {
        // VBRz swap completado
        await prisma.vBRzTransaction.create({
          data: {
            type: 'TRANSFER',
            amount: data.amount,
            fromAddress: data.from,
            toAddress: data.to,
            txHash: data.txHash,
            description: `Swap ${data.fromCurrency} -> ${data.toCurrency}`,
          },
        });
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error('Transfero webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// WhatsApp Webhook (Baileys callback)
router.post('/whatsapp', async (req, res) => {
  try {
    const { type, message, from } = req.body;

    await prisma.webhookLog.create({
      data: {
        provider: 'whatsapp',
        event: type,
        payload: req.body,
      },
    });

    if (type === 'message') {
      // Buscar ou criar ticket
      let ticket = await prisma.ticket.findFirst({
        where: {
          contactPhone: from,
          status: { notIn: ['RESOLVED', 'CLOSED'] },
        },
      });

      if (!ticket) {
        ticket = await prisma.ticket.create({
          data: {
            contactPhone: from,
            contactName: message.pushName || from,
            channel: 'WHATSAPP',
          },
        });
      }

      // Criar mensagem
      await prisma.message.create({
        data: {
          ticketId: ticket.id,
          content: message.body,
          contentType: message.type === 'image' ? 'IMAGE' : 'TEXT',
          senderType: 'CUSTOMER',
          senderName: message.pushName,
          channel: 'WHATSAPP',
          externalId: message.id,
        },
      });

      // Adicionar job para IA responder
      await redis.lpush('ai:process', JSON.stringify({
        ticketId: ticket.id,
        message: message.body,
      }));
    }

    res.json({ received: true });
  } catch (error) {
    logger.error('WhatsApp webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Blockchain Events (Polygon listener)
router.post('/blockchain', async (req, res) => {
  try {
    const { event, data, txHash } = req.body;

    // Verificar assinatura
    const signature = req.headers['x-blockchain-signature'];
    const expectedSignature = crypto
      .createHmac('sha256', process.env.BLOCKCHAIN_WEBHOOK_SECRET || '')
      .update(JSON.stringify(req.body))
      .digest('hex');

    if (signature !== expectedSignature) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    await prisma.webhookLog.create({
      data: {
        provider: 'blockchain',
        event,
        payload: req.body,
      },
    });

    logger.info(`Blockchain event: ${event}`);

    switch (event) {
      case 'NFT_MINTED': {
        await prisma.blockchainTransaction.create({
          data: {
            txHash,
            type: 'MINT_NFT',
            status: 'CONFIRMED',
            fromAddress: data.from,
            toAddress: data.to,
            value: 0,
            confirmedAt: new Date(),
          },
        });
        break;
      }

      case 'SPLIT_EXECUTED': {
        // Split de pagamento executado
        await prisma.blockchainTransaction.create({
          data: {
            txHash,
            type: 'SPLIT_PAYMENT',
            status: 'CONFIRMED',
            fromAddress: data.from,
            toAddress: data.treasury,
            value: data.amount,
            confirmedAt: new Date(),
          },
        });
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error('Blockchain webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

export default router;
