// ============================================
// PROPERTIES ROUTES
// ============================================

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { AppError } from '../middleware/error-handler.js';
import { requirePermission } from '../middleware/auth.js';

const router = Router();

// List properties
router.get('/', requirePermission('properties.view'), async (req, res, next) => {
  try {
    const { page = '1', limit = '10', status, type, city } = req.query;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (type) where.type = type;
    if (city) where.city = { contains: city as string, mode: 'insensitive' };

    const [properties, total] = await Promise.all([
      prisma.property.findMany({
        where,
        include: {
          owner: { select: { id: true, name: true, email: true } },
          images: { take: 1, orderBy: { order: 'asc' } },
          _count: { select: { contracts: true, inspections: true } },
        },
        skip: (parseInt(page as string) - 1) * parseInt(limit as string),
        take: parseInt(limit as string),
        orderBy: { createdAt: 'desc' },
      }),
      prisma.property.count({ where }),
    ]);

    res.json({
      properties,
      total,
      page: parseInt(page as string),
      totalPages: Math.ceil(total / parseInt(limit as string)),
    });
  } catch (error) {
    next(error);
  }
});

// Get property by ID
router.get('/:id', requirePermission('properties.view'), async (req, res, next) => {
  try {
    const property = await prisma.property.findUnique({
      where: { id: req.params.id },
      include: {
        owner: { select: { id: true, name: true, email: true, phone: true } },
        images: { orderBy: { order: 'asc' } },
        inspections: { orderBy: { scheduledAt: 'desc' }, take: 5 },
        contracts: {
          orderBy: { createdAt: 'desc' },
          include: { nft: true },
        },
      },
    });

    if (!property) {
      throw new AppError(404, 'Property not found');
    }

    res.json(property);
  } catch (error) {
    next(error);
  }
});

// Create property
router.post('/', requirePermission('properties.create'), async (req, res, next) => {
  try {
    const schema = z.object({
      ownerId: z.string().uuid(),
      title: z.string().min(5),
      description: z.string().optional(),
      type: z.enum(['APARTMENT', 'HOUSE', 'COMMERCIAL', 'LAND', 'STUDIO', 'LOFT', 'PENTHOUSE']),
      street: z.string(),
      number: z.string(),
      complement: z.string().optional(),
      neighborhood: z.string(),
      city: z.string(),
      state: z.string(),
      zipCode: z.string(),
      area: z.number().optional(),
      bedrooms: z.number().optional(),
      bathrooms: z.number().optional(),
      parkingSpaces: z.number().optional(),
      floor: z.number().optional(),
      furnished: z.boolean().optional(),
      petFriendly: z.boolean().optional(),
      rentValue: z.number().positive(),
      condoFee: z.number().optional(),
      iptuValue: z.number().optional(),
    });

    const data = schema.parse(req.body);

    const property = await prisma.property.create({
      data,
      include: { owner: { select: { id: true, name: true } } },
    });

    res.status(201).json(property);
  } catch (error) {
    next(error);
  }
});

// Update property
router.patch('/:id', requirePermission('properties.update'), async (req, res, next) => {
  try {
    const property = await prisma.property.update({
      where: { id: req.params.id },
      data: req.body,
    });

    res.json(property);
  } catch (error) {
    next(error);
  }
});

// Delete property
router.delete('/:id', requirePermission('properties.delete'), async (req, res, next) => {
  try {
    await prisma.property.delete({
      where: { id: req.params.id },
    });

    res.json({ message: 'Property deleted successfully' });
  } catch (error) {
    next(error);
  }
});

// Add images
router.post('/:id/images', requirePermission('properties.update'), async (req, res, next) => {
  try {
    const { images } = req.body;

    const created = await prisma.propertyImage.createMany({
      data: images.map((img: { url: string; caption?: string }, i: number) => ({
        propertyId: req.params.id,
        url: img.url,
        caption: img.caption,
        order: i,
      })),
    });

    res.status(201).json({ count: created.count });
  } catch (error) {
    next(error);
  }
});

export default router;
