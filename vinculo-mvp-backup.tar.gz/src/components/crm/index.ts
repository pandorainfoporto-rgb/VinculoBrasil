// =============================================================================
// Vínculo CRM - Exports
// =============================================================================

// Componente Principal
export { CRMDashboard } from './crm-dashboard';

// Kanban
export { KanbanBoard, DealDetailModal } from './kanban';

// Store
export { useCRMStore } from './store';

// Serviços
export { leadIngestionService, LeadIngestionService } from './services/lead-ingestion-service';

// Tipos
export * from './types';
