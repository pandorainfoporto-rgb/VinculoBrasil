// =============================================================================
// CashbackAdminDashboard - Painel Admin do Sistema de Cashback VBRz
// =============================================================================

import * as React from 'react';
import {
  Coins,
  TrendingUp,
  Users,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Building,
  UserCheck,
  ShoppingBag,
  Shield,
  Gift,
  Star,
  Settings,
  Download,
  RefreshCw,
  AlertTriangle,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  type CashbackCategory,
  type CashbackAdminStats,
  CASHBACK_CATEGORY_LABELS,
  MOCK_ADMIN_STATS,
} from '@/lib/cashback-admin-types';
import { VBRZ_CONFIG, formatVBRz, LOYALTY_TIER_LABELS, type LoyaltyTier } from '@/lib/tokenomics-types';
import { CashbackRulesPanel } from './cashback-rules-panel';
import { CashbackTransactionsTable } from './cashback-transactions-table';
import { CashbackAnalytics } from './cashback-analytics';

// =============================================================================
// COMPONENTE PRINCIPAL
// =============================================================================

export function CashbackAdminDashboard() {
  const [stats, setStats] = React.useState<CashbackAdminStats>(MOCK_ADMIN_STATS);
  const [isLoading, setIsLoading] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState('overview');

  const refreshData = React.useCallback(async () => {
    setIsLoading(true);
    // Simula refresh
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setStats(MOCK_ADMIN_STATS);
    setIsLoading(false);
  }, []);

  const treasuryPercentage = (stats.treasuryBalance / (VBRZ_CONFIG.maxSupply * 100)) * 100;
  const isTreasuryLow = treasuryPercentage < 10;

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestão de Cashback VBRz</h1>
          <p className="text-muted-foreground">
            Gerencie regras, monitore distribuições e analise métricas do programa de fidelidade
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isLoading}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Button size="sm">
            <Settings className="mr-2 h-4 w-4" />
            Configurações
          </Button>
        </div>
      </div>

      {/* Alerta Treasury */}
      {isTreasuryLow && (
        <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <div className="flex-1">
            <p className="font-medium text-amber-800">Treasury com saldo baixo</p>
            <p className="text-sm text-amber-700">
              O saldo do treasury está abaixo de 10%. Considere reduzir taxas de cashback ou adicionar fundos.
            </p>
          </div>
          <Button variant="outline" size="sm" className="border-amber-300 text-amber-700 hover:bg-amber-100">
            Ver Detalhes
          </Button>
        </div>
      )}

      {/* KPIs Principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Distribuído"
          value={formatVBRz(stats.totalDistributed)}
          suffix="VBRz"
          subValue={`≈ R$ ${formatVBRz(stats.totalDistributedBRL)}`}
          icon={Coins}
          trend={{ value: 12.5, isPositive: true }}
          variant="primary"
        />
        <StatsCard
          title="Transações"
          value={stats.totalTransactions.toLocaleString('pt-BR')}
          subValue={`${stats.distributedToday.toLocaleString('pt-BR')} VBRz hoje`}
          icon={TrendingUp}
          trend={{ value: 8.2, isPositive: true }}
        />
        <StatsCard
          title="Usuários Ativos"
          value={stats.totalUsers.toLocaleString('pt-BR')}
          subValue="com saldo VBRz"
          icon={Users}
          trend={{ value: 5.1, isPositive: true }}
        />
        <StatsCard
          title="Treasury"
          value={formatVBRz(stats.treasuryBalance)}
          suffix="VBRz"
          subValue={`${treasuryPercentage.toFixed(1)}% do supply`}
          icon={Wallet}
          variant={isTreasuryLow ? 'warning' : 'default'}
        />
      </div>

      {/* Distribuição por Categoria */}
      <Card>
        <CardHeader>
          <CardTitle>Distribuição por Categoria</CardTitle>
          <CardDescription>Cashback distribuído por tipo de operação</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {Object.entries(stats.byCategory).map(([category, categoryStats]) => (
              <CategoryCard
                key={category}
                category={category as CashbackCategory}
                stats={categoryStats}
                total={stats.totalDistributed}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tabs de Conteúdo */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-none">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="transactions">Transações</TabsTrigger>
          <TabsTrigger value="rules">Regras</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            {/* Por Tipo de Usuário */}
            <Card>
              <CardHeader>
                <CardTitle>Por Tipo de Usuário</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(stats.byUserRole).map(([role, roleStats]) => (
                  <div key={role} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium capitalize">
                        {role === 'tenant'
                          ? 'Inquilinos'
                          : role === 'landlord'
                            ? 'Proprietários'
                            : role === 'guarantor'
                              ? 'Garantidores'
                              : 'Admins'}
                      </span>
                      <span className="text-muted-foreground">
                        {formatVBRz(roleStats.totalVBRz)} VBRz ({roleStats.userCount.toLocaleString('pt-BR')} usuários)
                      </span>
                    </div>
                    <Progress value={(roleStats.totalVBRz / stats.totalDistributed) * 100} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Por Tier de Fidelidade */}
            <Card>
              <CardHeader>
                <CardTitle>Por Tier de Fidelidade</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(stats.byTier).map(([tier, amount]) => (
                  <div key={tier} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <TierBadge tier={tier as LoyaltyTier} />
                        <span className="font-medium">{LOYALTY_TIER_LABELS[tier as LoyaltyTier]}</span>
                      </div>
                      <span className="text-muted-foreground">{formatVBRz(amount)} VBRz</span>
                    </div>
                    <Progress value={(amount / stats.totalDistributed) * 100} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Tendência 7 dias */}
          <Card>
            <CardHeader>
              <CardTitle>Tendência Últimos 7 Dias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex h-48 items-end gap-2">
                {stats.trend7Days.map((day, index) => {
                  const maxDistributed = Math.max(...stats.trend7Days.map((d) => d.distributed));
                  const heightPercent = (day.distributed / maxDistributed) * 100;
                  return (
                    <div key={index} className="flex flex-1 flex-col items-center gap-1">
                      <div
                        className="w-full rounded-t bg-primary transition-all hover:bg-primary/80"
                        style={{ height: `${heightPercent}%`, minHeight: '8px' }}
                      />
                      <span className="text-xs text-muted-foreground">
                        {new Date(day.date).toLocaleDateString('pt-BR', { weekday: 'short' })}
                      </span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions">
          <CashbackTransactionsTable />
        </TabsContent>

        <TabsContent value="rules">
          <CashbackRulesPanel />
        </TabsContent>

        <TabsContent value="analytics">
          <CashbackAnalytics stats={stats} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// =============================================================================
// COMPONENTES AUXILIARES
// =============================================================================

interface StatsCardProps {
  title: string;
  value: string;
  suffix?: string;
  subValue?: string;
  icon: React.ElementType;
  trend?: { value: number; isPositive: boolean };
  variant?: 'default' | 'primary' | 'warning';
}

function StatsCard({ title, value, suffix, subValue, icon: Icon, trend, variant = 'default' }: StatsCardProps) {
  const bgClass =
    variant === 'primary'
      ? 'bg-primary/5 border-primary/20'
      : variant === 'warning'
        ? 'bg-amber-50 border-amber-200'
        : '';

  return (
    <Card className={bgClass}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon
          className={`h-4 w-4 ${variant === 'primary' ? 'text-primary' : variant === 'warning' ? 'text-amber-600' : 'text-muted-foreground'}`}
        />
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold">{value}</span>
          {suffix && <span className="text-sm text-muted-foreground">{suffix}</span>}
        </div>
        <div className="flex items-center justify-between">
          {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
          {trend && (
            <div className={`flex items-center text-xs ${trend.isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {trend.isPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              <span>{trend.value}%</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface CategoryCardProps {
  category: CashbackCategory;
  stats: {
    totalVBRz: number;
    totalBRL: number;
    transactionCount: number;
    userCount: number;
    averagePerTransaction: number;
  };
  total: number;
}

function CategoryCard({ category, stats, total }: CategoryCardProps) {
  const percentage = (stats.totalVBRz / total) * 100;

  const iconMap: Record<CashbackCategory, React.ElementType> = {
    tenant: Users,
    landlord: Building,
    guarantor: UserCheck,
    marketplace: ShoppingBag,
    insurance: Shield,
    financial: Wallet,
    referral: Gift,
    loyalty: Star,
    promotional: Gift,
  };

  const Icon = iconMap[category];

  return (
    <div className="flex items-center gap-4 rounded-lg border p-4">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div className="flex-1 space-y-1">
        <div className="flex items-center justify-between">
          <span className="font-medium">{CASHBACK_CATEGORY_LABELS[category]}</span>
          <Badge variant="outline">{percentage.toFixed(1)}%</Badge>
        </div>
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>{formatVBRz(stats.totalVBRz)} VBRz</span>
          <span>{stats.transactionCount.toLocaleString('pt-BR')} txs</span>
        </div>
        <Progress value={percentage} className="h-1" />
      </div>
    </div>
  );
}

function TierBadge({ tier }: { tier: LoyaltyTier }) {
  const colors: Record<LoyaltyTier, string> = {
    bronze: 'bg-amber-700',
    prata: 'bg-gray-400',
    ouro: 'bg-yellow-500',
    diamante: 'bg-cyan-400',
  };

  return <div className={`h-3 w-3 rounded-full ${colors[tier]}`} />;
}

export default CashbackAdminDashboard;
