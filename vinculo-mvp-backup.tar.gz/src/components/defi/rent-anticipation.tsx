// =============================================================================
// Rent Anticipation - Antecipacao de Aluguel DeFi
// =============================================================================
// Interface para locadores anteciparem ate 12 meses de aluguel
// usando o contrato de aluguel (NFT) como garantia.
// =============================================================================

import { useState, useEffect, useMemo } from 'react';
import {
  Wallet,
  TrendingUp,
  Lock,
  Unlock,
  Calendar,
  DollarSign,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Info,
  Coins,
  Shield,
  Clock,
  FileText,
  ExternalLink,
  Percent,
} from 'lucide-react';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

import {
  type RentAnticipationLoan,
  type LiquidityPool,
  type LoanStatus,
  LOAN_STATUS_LABELS,
} from '@/lib/marketplace-types';

// -----------------------------------------------------------------------------
// Tipos
// -----------------------------------------------------------------------------

interface RentAnticipationProps {
  userId: string;
  userName?: string;
  contracts: ContractInfo[];
  walletConnected?: boolean;
  walletAddress?: string;
  onConnectWallet?: () => void;
}

interface ContractInfo {
  id: string;
  nftTokenId: string;
  propertyAddress: string;
  tenantName: string;
  monthlyRent: number;
  remainingMonths: number;
  isLocked: boolean;
  existingLoanId?: string;
}

interface SimulationResult {
  monthsSelected: number;
  grossAmount: number;
  discountRate: number;
  originationFee: number;
  platformFee: number;
  insuranceFee: number;
  totalFees: number;
  netAmount: number;
  monthlyRepayment: number;
  effectiveRate: number;
}

// -----------------------------------------------------------------------------
// Constantes
// -----------------------------------------------------------------------------

const BASE_DISCOUNT_RATE = 0.015; // 1.5% ao mes
const ORIGINATION_FEE_RATE = 0.02; // 2%
const PLATFORM_FEE_RATE = 0.005; // 0.5%
const INSURANCE_FEE_RATE = 0.003; // 0.3%

// -----------------------------------------------------------------------------
// Dados Vazios para Producao - Pool vira do backend
// -----------------------------------------------------------------------------

const EMPTY_POOL: LiquidityPool = {
  id: '',
  name: '',
  tokenSymbol: '',
  totalDeposited: 0,
  totalBorrowed: 0,
  availableLiquidity: 0,
  utilizationRate: 0,
  depositAPY: 0,
  borrowAPR: 0,
  platformFeeRate: 0,
  reserveFactor: 0,
  contractAddress: '',
  chainId: 0,
  lastUpdated: new Date(),
};

// -----------------------------------------------------------------------------
// Componente Principal
// -----------------------------------------------------------------------------

export function RentAnticipation({
  userId,
  userName,
  contracts,
  walletConnected = false,
  walletAddress,
  onConnectWallet,
}: RentAnticipationProps) {
  const [selectedContract, setSelectedContract] = useState<ContractInfo | null>(null);
  const [monthsToAnticipate, setMonthsToAnticipate] = useState(6);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeLoans, setActiveLoans] = useState<RentAnticipationLoan[]>([]);

  // Seleciona primeiro contrato elegivel
  useEffect(() => {
    const eligibleContract = contracts.find((c) => !c.isLocked && c.remainingMonths >= 3);
    if (eligibleContract && !selectedContract) {
      setSelectedContract(eligibleContract);
    }
  }, [contracts, selectedContract]);

  // Calcula simulacao
  const simulation = useMemo((): SimulationResult | null => {
    if (!selectedContract) return null;

    const maxMonths = Math.min(12, selectedContract.remainingMonths);
    const months = Math.min(monthsToAnticipate, maxMonths);

    const grossAmount = selectedContract.monthlyRent * months;

    // Calcula taxa de desconto (quanto mais meses, maior a taxa)
    const discountRate = BASE_DISCOUNT_RATE * months;
    const discountAmount = grossAmount * discountRate;

    // Taxas
    const originationFee = grossAmount * ORIGINATION_FEE_RATE;
    const platformFee = grossAmount * PLATFORM_FEE_RATE;
    const insuranceFee = grossAmount * INSURANCE_FEE_RATE;
    const totalFees = originationFee + platformFee + insuranceFee;

    // Valor liquido
    const netAmount = grossAmount - discountAmount - totalFees;

    // Parcela mensal (85% do aluguel vai para repor o pool)
    const monthlyRepayment = selectedContract.monthlyRent * 0.85;

    // Taxa efetiva anualizada
    const effectiveRate = ((grossAmount - netAmount) / netAmount) * (12 / months) * 100;

    return {
      monthsSelected: months,
      grossAmount,
      discountRate: discountRate * 100,
      originationFee,
      platformFee,
      insuranceFee,
      totalFees,
      netAmount,
      monthlyRepayment,
      effectiveRate,
    };
  }, [selectedContract, monthsToAnticipate]);

  const handleAnticipate = async () => {
    if (!selectedContract || !simulation) return;

    setIsProcessing(true);

    try {
      // Simula processo de antecipacao
      await new Promise((resolve) => setTimeout(resolve, 3000));

      // Cria loan mockado
      const newLoan: RentAnticipationLoan = {
        id: `loan_${Date.now()}`,
        poolId: EMPTY_POOL.id,
        borrowerId: userId,
        contractId: selectedContract.id,
        nftTokenId: selectedContract.nftTokenId,
        nftContractAddress: '0xVinculoNFT',
        nftLocked: true,
        monthlyRent: selectedContract.monthlyRent,
        monthsAnticipated: simulation.monthsSelected,
        totalContractValue: simulation.grossAmount,
        discountRate: simulation.discountRate,
        grossLoanAmount: simulation.grossAmount,
        fees: {
          originationFee: simulation.originationFee,
          platformFee: simulation.platformFee,
          insuranceFee: simulation.insuranceFee,
          totalFees: simulation.totalFees,
        },
        netLoanAmount: simulation.netAmount,
        monthlyRepayment: simulation.monthlyRepayment,
        remainingDebt: simulation.grossAmount,
        paidInstallments: 0,
        totalInstallments: simulation.monthsSelected,
        status: 'ativo',
        daysOverdue: 0,
        loanTxHash: '0x' + Math.random().toString(16).slice(2, 66),
        repaymentTxHashes: [],
        requestedAt: new Date(),
        approvedAt: new Date(),
        disbursedAt: new Date(),
      };

      setActiveLoans((prev) => [...prev, newLoan]);
      setIsConfirmDialogOpen(false);

      // Atualiza contrato como bloqueado
      setSelectedContract(null);

      alert(`Sucesso! R$ ${simulation.netAmount.toFixed(2)} transferidos para sua carteira.`);
    } catch (error) {
      console.error('Erro na antecipacao:', error);
      alert('Erro ao processar antecipacao. Tente novamente.');
    } finally {
      setIsProcessing(false);
    }
  };

  const maxMonths = selectedContract
    ? Math.min(12, selectedContract.remainingMonths)
    : 12;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="h-7 w-7 text-primary" />
            Vinculo DeFi
          </h1>
          <p className="text-muted-foreground">
            Antecipe ate 12 meses de aluguel usando seu contrato como garantia
          </p>
        </div>

        {!walletConnected ? (
          <Button onClick={onConnectWallet} className="gap-2">
            <Wallet className="h-4 w-4" />
            Conectar Carteira
          </Button>
        ) : (
          <Badge variant="outline" className="text-sm py-2 px-3">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
              {walletAddress?.slice(0, 6)}...{walletAddress?.slice(-4)}
            </div>
          </Badge>
        )}
      </div>

      {/* Pool Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Coins className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Liquidez Disponivel</p>
                <p className="text-xl font-bold">
                  R$ {(EMPTY_POOL.availableLiquidity / 1000).toFixed(0)}k
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">APY Investidor</p>
                <p className="text-xl font-bold text-green-600">
                  {EMPTY_POOL.depositAPY}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Percent className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Taxa Antecipacao</p>
                <p className="text-xl font-bold">
                  {(BASE_DISCOUNT_RATE * 100).toFixed(1)}%/mes
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Shield className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Utilizacao do Pool</p>
                <p className="text-xl font-bold">{EMPTY_POOL.utilizationRate}%</p>
              </div>
            </div>
            <Progress value={EMPTY_POOL.utilizationRate} className="mt-2 h-1" />
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Selecao de Contrato */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Seus Contratos</CardTitle>
            <CardDescription>
              Selecione o contrato para antecipar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {contracts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum contrato elegivel</p>
              </div>
            ) : (
              contracts.map((contract) => (
                <div
                  key={contract.id}
                  className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                    selectedContract?.id === contract.id
                      ? 'border-primary bg-primary/5'
                      : contract.isLocked
                      ? 'border-muted bg-muted/30 opacity-60 cursor-not-allowed'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => !contract.isLocked && setSelectedContract(contract)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-sm line-clamp-1">
                        {contract.propertyAddress}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Inquilino: {contract.tenantName}
                      </p>
                    </div>
                    {contract.isLocked && (
                      <Lock className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>

                  <Separator className="my-3" />

                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Aluguel</span>
                    <span className="font-medium">
                      R$ {contract.monthlyRent.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-muted-foreground">Meses restantes</span>
                    <span className="font-medium">{contract.remainingMonths}</span>
                  </div>

                  {contract.isLocked && (
                    <Badge variant="secondary" className="mt-3 w-full justify-center">
                      <Lock className="h-3 w-3 mr-1" />
                      NFT Bloqueado
                    </Badge>
                  )}
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Simulador */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Simular Antecipacao
            </CardTitle>
            <CardDescription>
              Escolha quantos meses deseja antecipar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {!selectedContract ? (
              <div className="text-center py-12 text-muted-foreground">
                <ArrowRight className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Selecione um contrato para simular</p>
              </div>
            ) : (
              <>
                {/* Slider de meses */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Meses a antecipar</span>
                    <span className="text-2xl font-bold text-primary">
                      {monthsToAnticipate}
                    </span>
                  </div>
                  <Slider
                    value={[monthsToAnticipate]}
                    onValueChange={(value) => setMonthsToAnticipate(value[0])}
                    min={1}
                    max={maxMonths}
                    step={1}
                    className="py-4"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>1 mes</span>
                    <span>{maxMonths} meses</span>
                  </div>
                </div>

                <Separator />

                {/* Resultado da simulacao */}
                {simulation && (
                  <div className="space-y-4">
                    {/* Valor disponivel */}
                    <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl p-6 text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        Valor disponivel para saque
                      </p>
                      <p className="text-4xl font-bold text-primary">
                        R$ {simulation.netAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">
                        Transferencia instantanea para sua carteira
                      </p>
                    </div>

                    {/* Detalhes */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Valor bruto</span>
                          <span>R$ {simulation.grossAmount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger className="text-muted-foreground flex items-center gap-1">
                                Taxa de desconto
                                <Info className="h-3 w-3" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{simulation.discountRate.toFixed(1)}% para {simulation.monthsSelected} meses</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          <span className="text-red-500">
                            -R$ {(simulation.grossAmount * simulation.discountRate / 100).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Taxas totais</span>
                          <span className="text-red-500">
                            -R$ {simulation.totalFees.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Parcela mensal</span>
                          <span>R$ {simulation.monthlyRepayment.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Total de parcelas</span>
                          <span>{simulation.monthsSelected}x</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Taxa efetiva a.a.</span>
                          <span>{simulation.effectiveRate.toFixed(1)}%</span>
                        </div>
                      </div>
                    </div>

                    {/* Alerta */}
                    <Alert>
                      <Lock className="h-4 w-4" />
                      <AlertTitle>NFT como Garantia</AlertTitle>
                      <AlertDescription>
                        Seu NFT do contrato ficara bloqueado ate a quitacao completa.
                        Os pagamentos mensais do inquilino serao automaticamente
                        direcionados para repor o pool.
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </>
            )}
          </CardContent>
          <CardFooter>
            <Button
              className="w-full"
              size="lg"
              disabled={!selectedContract || !walletConnected}
              onClick={() => setIsConfirmDialogOpen(true)}
            >
              {!walletConnected ? (
                <>
                  <Wallet className="h-4 w-4 mr-2" />
                  Conecte sua carteira
                </>
              ) : (
                <>
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Antecipar Agora
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Emprestimos Ativos */}
      {activeLoans.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Antecipacoes Ativas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeLoans.map((loan) => (
                <div
                  key={loan.id}
                  className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg gap-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Lock className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">
                        {loan.monthsAnticipated} meses antecipados
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Recebido: R$ {loan.netLoanAmount.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">Parcelas pagas</p>
                      <p className="font-medium">
                        {loan.paidInstallments}/{loan.totalInstallments}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground">Saldo devedor</p>
                      <p className="font-medium">
                        R$ {loan.remainingDebt.toLocaleString()}
                      </p>
                    </div>
                    <Badge
                      variant={loan.status === 'ativo' ? 'default' : 'secondary'}
                    >
                      {LOAN_STATUS_LABELS[loan.status]}
                    </Badge>
                  </div>

                  <Progress
                    value={(loan.paidInstallments / loan.totalInstallments) * 100}
                    className="h-2 md:w-32"
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Como Funciona */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Como Funciona</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-medium mb-1">1. Selecione</h4>
              <p className="text-sm text-muted-foreground">
                Escolha o contrato NFT que deseja usar como garantia
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
              <h4 className="font-medium mb-1">2. Simule</h4>
              <p className="text-sm text-muted-foreground">
                Defina quantos meses quer antecipar e veja o valor liquido
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                <Lock className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-medium mb-1">3. Bloqueie</h4>
              <p className="text-sm text-muted-foreground">
                Seu NFT e travado no smart contract como garantia
              </p>
            </div>
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-3">
                <Coins className="h-6 w-6 text-amber-600" />
              </div>
              <h4 className="font-medium mb-1">4. Receba</h4>
              <p className="text-sm text-muted-foreground">
                Valor transferido instantaneamente para sua carteira
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dialog de Confirmacao */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Antecipacao</DialogTitle>
            <DialogDescription>
              Revise os termos antes de confirmar a operacao
            </DialogDescription>
          </DialogHeader>

          {simulation && selectedContract && (
            <div className="space-y-4 py-4">
              <div className="bg-primary/5 rounded-lg p-4 text-center">
                <p className="text-sm text-muted-foreground">Voce recebera</p>
                <p className="text-3xl font-bold text-primary">
                  R$ {simulation.netAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Contrato</span>
                  <span className="font-medium">{selectedContract.propertyAddress}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Meses antecipados</span>
                  <span className="font-medium">{simulation.monthsSelected}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Parcela mensal</span>
                  <span className="font-medium">
                    R$ {simulation.monthlyRepayment.toLocaleString()}
                  </span>
                </div>
              </div>

              <Alert variant="destructive" className="bg-amber-50 border-amber-200">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-800">
                  Seu NFT ficara bloqueado ate a quitacao. Em caso de inadimplencia,
                  o NFT pode ser liquidado.
                </AlertDescription>
              </Alert>

              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 mt-0.5 text-green-500" />
                <span>
                  Os pagamentos do inquilino serao automaticamente redirecionados
                  para quitar sua antecipacao.
                </span>
              </div>
            </div>
          )}

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setIsConfirmDialogOpen(false)}
              disabled={isProcessing}
            >
              Cancelar
            </Button>
            <Button onClick={handleAnticipate} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Processando...
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Confirmar e Bloquear NFT
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default RentAnticipation;
