// =============================================================================
// Vínculo Engage - Zustand Store
// =============================================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  type MarketingCampaign,
  type MessageTemplate,
  type AudienceSegment,
  type SmtpConfig,
  type CommunicationRule,
  type CampaignMessage,
  type QueueStats,
  type EngageDashboardStats,
  type CampaignStatus,
  type ChannelType,
} from './types';

// -----------------------------------------------------------------------------
// Interface da Store
// -----------------------------------------------------------------------------

interface EngageState {
  // Campanhas
  campaigns: MarketingCampaign[];
  selectedCampaign: MarketingCampaign | null;
  campaignFilter: {
    status?: CampaignStatus;
    channel?: ChannelType;
    search: string;
  };

  // Templates
  templates: MessageTemplate[];
  selectedTemplate: MessageTemplate | null;

  // Segmentos
  segments: AudienceSegment[];
  selectedSegment: AudienceSegment | null;

  // Configurações SMTP
  smtpConfigs: SmtpConfig[];
  selectedSmtpConfig: SmtpConfig | null;

  // Réguas de Comunicação
  communicationRules: CommunicationRule[];
  selectedRule: CommunicationRule | null;

  // Mensagens de Campanha
  campaignMessages: CampaignMessage[];

  // Estatísticas
  dashboardStats: EngageDashboardStats | null;
  queueStats: QueueStats | null;

  // UI State
  isLoading: boolean;
  activeTab: 'dashboard' | 'campaigns' | 'templates' | 'segments' | 'rules' | 'smtp' | 'queue';

  // Actions - Campanhas
  addCampaign: (campaign: MarketingCampaign) => void;
  updateCampaign: (id: string, updates: Partial<MarketingCampaign>) => void;
  deleteCampaign: (id: string) => void;
  selectCampaign: (campaign: MarketingCampaign | null) => void;
  setCampaignFilter: (filter: Partial<EngageState['campaignFilter']>) => void;
  updateCampaignStatus: (id: string, status: CampaignStatus) => void;

  // Actions - Templates
  addTemplate: (template: MessageTemplate) => void;
  updateTemplate: (id: string, updates: Partial<MessageTemplate>) => void;
  deleteTemplate: (id: string) => void;
  selectTemplate: (template: MessageTemplate | null) => void;

  // Actions - Segmentos
  addSegment: (segment: AudienceSegment) => void;
  updateSegment: (id: string, updates: Partial<AudienceSegment>) => void;
  deleteSegment: (id: string) => void;
  selectSegment: (segment: AudienceSegment | null) => void;

  // Actions - SMTP
  addSmtpConfig: (config: SmtpConfig) => void;
  updateSmtpConfig: (id: string, updates: Partial<SmtpConfig>) => void;
  deleteSmtpConfig: (id: string) => void;
  selectSmtpConfig: (config: SmtpConfig | null) => void;
  setDefaultSmtpConfig: (id: string) => void;

  // Actions - Réguas
  addCommunicationRule: (rule: CommunicationRule) => void;
  updateCommunicationRule: (id: string, updates: Partial<CommunicationRule>) => void;
  deleteCommunicationRule: (id: string) => void;
  selectCommunicationRule: (rule: CommunicationRule | null) => void;

  // Actions - Mensagens
  setCampaignMessages: (messages: CampaignMessage[]) => void;

  // Actions - Stats
  setDashboardStats: (stats: EngageDashboardStats) => void;
  setQueueStats: (stats: QueueStats) => void;

  // Actions - UI
  setLoading: (loading: boolean) => void;
  setActiveTab: (tab: EngageState['activeTab']) => void;

  // Helpers
  getFilteredCampaigns: () => MarketingCampaign[];
  getTemplatesByChannel: (channel: ChannelType) => MessageTemplate[];
  getDefaultSmtpConfig: () => SmtpConfig | undefined;
}

// -----------------------------------------------------------------------------
// Dados Iniciais de Demonstração
// -----------------------------------------------------------------------------

const initialTemplates: MessageTemplate[] = [
  {
    id: 'tpl-1',
    name: 'Lembrete de Vencimento - 3 Dias',
    channel: 'email',
    subject: 'Seu aluguel vence em 3 dias - {{contract.address}}',
    htmlContent: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a1a1a;">Olá, {{lead.name}}!</h2>
        <p>Este é um lembrete amigável de que seu aluguel do imóvel <strong>{{contract.address}}</strong> vence em <strong>3 dias</strong>.</p>
        <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Valor:</strong> {{contract.value}}</p>
          <p style="margin: 10px 0 0;"><strong>Vencimento:</strong> {{contract.due_date}}</p>
        </div>
        <p>Para sua comodidade, segue o boleto para pagamento:</p>
        <a href="{{boleto.url}}" style="display: inline-block; background: #2563eb; color: white; padding: 12px 24px; border-radius: 6px; text-decoration: none; margin: 10px 0;">Acessar Boleto</a>
        <p style="color: #666; font-size: 12px; margin-top: 30px;">Código de barras: {{boleto.barcode}}</p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />
        <p style="color: #666; font-size: 12px;">{{company.name}} - {{company.phone}}</p>
      </div>
    `,
    textContent: 'Olá, {{lead.name}}! Seu aluguel de {{contract.address}} vence em 3 dias. Valor: {{contract.value}}. Boleto: {{boleto.url}}',
    previewText: 'Não esqueça! Seu aluguel vence em breve.',
    category: 'cobranca',
    tags: ['cobranca', 'lembrete', 'boleto'],
    variables: ['lead.name', 'contract.address', 'contract.value', 'contract.due_date', 'boleto.url', 'boleto.barcode', 'company.name', 'company.phone'],
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'tpl-2',
    name: 'Lembrete de Vencimento - WhatsApp',
    channel: 'whatsapp',
    textContent: `Olá, {{lead.name}}! 👋

Passando para lembrar que seu aluguel vence em *3 dias*.

📍 *Imóvel:* {{contract.address}}
💰 *Valor:* {{contract.value}}
📅 *Vencimento:* {{contract.due_date}}

🔗 Acesse seu boleto: {{boleto.url}}

Ou copie o código PIX:
\`{{pix.code}}\`

Qualquer dúvida, estamos à disposição! 😊

_{{company.name}}_`,
    category: 'cobranca',
    tags: ['cobranca', 'lembrete', 'whatsapp'],
    variables: ['lead.name', 'contract.address', 'contract.value', 'contract.due_date', 'boleto.url', 'pix.code', 'company.name'],
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'tpl-3',
    name: 'Feliz Aniversário',
    channel: 'email',
    subject: '🎂 Feliz Aniversário, {{lead.name}}!',
    htmlContent: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; text-align: center;">
        <div style="font-size: 60px; margin: 30px 0;">🎂</div>
        <h1 style="color: #1a1a1a;">Feliz Aniversário, {{lead.name}}!</h1>
        <p style="font-size: 18px; color: #666;">Toda a equipe da {{company.name}} deseja a você um dia maravilhoso repleto de alegrias!</p>
        <p style="color: #666;">Que este novo ciclo traga muitas realizações e conquistas.</p>
        <div style="margin: 30px 0;">🎈🎉🎁</div>
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />
        <p style="color: #666; font-size: 12px;">{{company.name}} - {{company.phone}}</p>
      </div>
    `,
    textContent: 'Feliz Aniversário, {{lead.name}}! 🎂 Toda a equipe da {{company.name}} deseja a você um dia maravilhoso!',
    previewText: 'Hoje é um dia especial! Parabéns!',
    category: 'relacionamento',
    tags: ['aniversario', 'relacionamento'],
    variables: ['lead.name', 'company.name', 'company.phone'],
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'tpl-4',
    name: 'Feliz Aniversário - WhatsApp',
    channel: 'whatsapp',
    textContent: `🎂 *Feliz Aniversário, {{lead.name}}!* 🎉

Toda a equipe da *{{company.name}}* deseja a você um dia incrível, repleto de alegrias e momentos especiais!

Que este novo ciclo traga muitas realizações! 🎈

Um grande abraço! 💙

_{{company.name}}_`,
    category: 'relacionamento',
    tags: ['aniversario', 'relacionamento', 'whatsapp'],
    variables: ['lead.name', 'company.name'],
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'tpl-5',
    name: 'Boas-vindas - Onboarding Dia 1',
    channel: 'email',
    subject: 'Bem-vindo(a) à {{company.name}}! 🏠',
    htmlContent: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a1a1a;">Olá, {{lead.name}}! 👋</h2>
        <p>Seja muito bem-vindo(a) à <strong>{{company.name}}</strong>!</p>
        <p>Estamos muito felizes em tê-lo(a) conosco. A partir de agora, você conta com nossa equipe para ajudá-lo(a) em tudo relacionado ao seu imóvel.</p>
        <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
          <h3 style="margin: 0 0 10px; color: #1a1a1a;">📋 Próximos Passos:</h3>
          <ul style="margin: 0; padding-left: 20px; color: #666;">
            <li>Guarde nosso contato: {{company.phone}}</li>
            <li>Fique atento aos e-mails com informações importantes</li>
            <li>Qualquer dúvida, entre em contato!</li>
          </ul>
        </div>
        <p>Estamos à disposição!</p>
        <p style="color: #666;">Atenciosamente,<br/><strong>Equipe {{company.name}}</strong></p>
      </div>
    `,
    textContent: 'Olá, {{lead.name}}! Seja bem-vindo(a) à {{company.name}}! Estamos felizes em tê-lo(a) conosco. Guarde nosso contato: {{company.phone}}',
    previewText: 'Estamos felizes em tê-lo(a) conosco!',
    category: 'onboarding',
    tags: ['onboarding', 'boas-vindas', 'dia-1'],
    variables: ['lead.name', 'company.name', 'company.phone'],
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
];

const initialSegments: AudienceSegment[] = [
  {
    id: 'seg-1',
    name: 'Todos os Inquilinos Ativos',
    description: 'Inquilinos com contratos ativos',
    entityType: 'tenant',
    rules: [
      { id: 'r1', field: 'status', operator: 'equals', value: 'ACTIVE' },
    ],
    estimatedCount: 156,
    lastCalculatedAt: new Date(),
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'seg-2',
    name: 'Proprietários Premium',
    description: 'Proprietários com 3+ imóveis na carteira',
    entityType: 'landlord',
    rules: [
      { id: 'r1', field: 'properties_count', operator: 'greater_than', value: 3 },
    ],
    estimatedCount: 24,
    lastCalculatedAt: new Date(),
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'seg-3',
    name: 'Leads Quentes',
    description: 'Leads com temperatura quente nos últimos 7 dias',
    entityType: 'lead',
    rules: [
      { id: 'r1', field: 'temperature', operator: 'equals', value: 'quente' },
      { id: 'r2', field: 'created_days_ago', operator: 'less_than', value: 7, logicalOperator: 'AND' },
    ],
    estimatedCount: 42,
    lastCalculatedAt: new Date(),
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'seg-4',
    name: 'Aniversariantes do Mês',
    description: 'Todos que fazem aniversário no mês corrente',
    entityType: 'all',
    rules: [
      { id: 'r1', field: 'birthday_month', operator: 'equals', value: 'current_month' },
    ],
    estimatedCount: 18,
    lastCalculatedAt: new Date(),
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
  {
    id: 'seg-5',
    name: 'Contratos a Vencer em 3 Dias',
    description: 'Inquilinos com pagamento vencendo em 3 dias',
    entityType: 'tenant',
    rules: [
      { id: 'r1', field: 'next_due_days', operator: 'equals', value: 3 },
      { id: 'r2', field: 'status', operator: 'equals', value: 'ACTIVE', logicalOperator: 'AND' },
    ],
    estimatedCount: 12,
    lastCalculatedAt: new Date(),
    isActive: true,
    createdBy: 'system',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
  },
];

const initialCampaigns: MarketingCampaign[] = [
  {
    id: 'cmp-1',
    name: 'Cobrança Automática - 3 Dias Antes',
    description: 'Envio automático de lembrete 3 dias antes do vencimento',
    type: 'automated',
    channel: 'email',
    status: 'scheduled',
    templateId: 'tpl-1',
    segmentId: 'seg-5',
    triggerType: 'due_date_reminder',
    triggerDaysBefore: 3,
    triggerTime: '08:00',
    batchSize: 50,
    batchDelayMs: 1000,
    maxRetries: 3,
    totalRecipients: 12,
    sentCount: 0,
    deliveredCount: 0,
    openedCount: 0,
    clickedCount: 0,
    failedCount: 0,
    bouncedCount: 0,
    createdBy: 'admin',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
  },
  {
    id: 'cmp-2',
    name: 'Aniversariantes de Janeiro',
    description: 'Parabéns automático para aniversariantes',
    type: 'automated',
    channel: 'whatsapp',
    status: 'scheduled',
    templateId: 'tpl-4',
    segmentId: 'seg-4',
    triggerType: 'birthday',
    triggerTime: '09:00',
    batchSize: 20,
    batchDelayMs: 2000,
    maxRetries: 2,
    totalRecipients: 18,
    sentCount: 8,
    deliveredCount: 8,
    openedCount: 0,
    clickedCount: 0,
    failedCount: 0,
    bouncedCount: 0,
    startedAt: new Date('2024-01-01'),
    createdBy: 'admin',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-15'),
  },
  {
    id: 'cmp-3',
    name: 'Newsletter Semanal - Novos Imóveis',
    description: 'Divulgação de novos imóveis disponíveis',
    type: 'one_time',
    channel: 'email',
    status: 'completed',
    templateId: 'tpl-1',
    segmentId: 'seg-3',
    triggerType: 'manual',
    scheduledAt: new Date('2024-01-10T10:00:00'),
    batchSize: 100,
    batchDelayMs: 500,
    maxRetries: 3,
    totalRecipients: 42,
    sentCount: 42,
    deliveredCount: 40,
    openedCount: 28,
    clickedCount: 12,
    failedCount: 2,
    bouncedCount: 0,
    startedAt: new Date('2024-01-10T10:00:00'),
    completedAt: new Date('2024-01-10T10:05:00'),
    createdBy: 'marketing',
    createdAt: new Date('2024-01-09'),
    updatedAt: new Date('2024-01-10'),
  },
];

const initialSmtpConfigs: SmtpConfig[] = [
  {
    id: 'smtp-1',
    name: 'Servidor Principal',
    host: 'smtp.example.com',
    port: 587,
    user: 'noreply@vinculoimob.com.br',
    password: '********',
    secure: false,
    fromEmail: 'noreply@vinculoimob.com.br',
    fromName: 'Vínculo Imobiliária',
    isDefault: true,
    isActive: true,
    lastTestedAt: new Date('2024-01-15'),
    lastTestResult: 'success',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-15'),
  },
];

const initialDashboardStats: EngageDashboardStats = {
  totalCampaigns: 15,
  activeCampaigns: 3,
  totalSent: 1250,
  totalDelivered: 1198,
  deliveryRate: 95.8,
  openRate: 42.5,
  clickRate: 12.3,
  bounceRate: 1.2,
  emailStats: {
    sent: 850,
    delivered: 820,
    opened: 380,
    clicked: 95,
  },
  whatsappStats: {
    sent: 400,
    delivered: 378,
    read: 320,
    replied: 45,
  },
  dailyStats: [
    { date: '2024-01-09', sent: 120, delivered: 115, opened: 52 },
    { date: '2024-01-10', sent: 85, delivered: 82, opened: 38 },
    { date: '2024-01-11', sent: 200, delivered: 192, opened: 88 },
    { date: '2024-01-12', sent: 150, delivered: 145, opened: 62 },
    { date: '2024-01-13', sent: 95, delivered: 91, opened: 41 },
    { date: '2024-01-14', sent: 180, delivered: 175, opened: 78 },
    { date: '2024-01-15', sent: 220, delivered: 210, opened: 95 },
  ],
  recentCampaigns: [],
  queueStats: {
    waiting: 45,
    active: 5,
    completed: 1198,
    failed: 7,
    delayed: 12,
    paused: false,
  },
};

// -----------------------------------------------------------------------------
// Criação da Store
// -----------------------------------------------------------------------------

export const useEngageStore = create<EngageState>()(
  persist(
    (set, get) => ({
      // Estado Inicial
      campaigns: initialCampaigns,
      selectedCampaign: null,
      campaignFilter: { search: '' },
      templates: initialTemplates,
      selectedTemplate: null,
      segments: initialSegments,
      selectedSegment: null,
      smtpConfigs: initialSmtpConfigs,
      selectedSmtpConfig: null,
      communicationRules: [],
      selectedRule: null,
      campaignMessages: [],
      dashboardStats: initialDashboardStats,
      queueStats: initialDashboardStats.queueStats,
      isLoading: false,
      activeTab: 'dashboard',

      // Actions - Campanhas
      addCampaign: (campaign) =>
        set((state) => ({
          campaigns: [campaign, ...state.campaigns],
        })),

      updateCampaign: (id, updates) =>
        set((state) => ({
          campaigns: state.campaigns.map((c) =>
            c.id === id ? { ...c, ...updates, updatedAt: new Date() } : c
          ),
          selectedCampaign:
            state.selectedCampaign?.id === id
              ? { ...state.selectedCampaign, ...updates, updatedAt: new Date() }
              : state.selectedCampaign,
        })),

      deleteCampaign: (id) =>
        set((state) => ({
          campaigns: state.campaigns.filter((c) => c.id !== id),
          selectedCampaign:
            state.selectedCampaign?.id === id ? null : state.selectedCampaign,
        })),

      selectCampaign: (campaign) => set({ selectedCampaign: campaign }),

      setCampaignFilter: (filter) =>
        set((state) => ({
          campaignFilter: { ...state.campaignFilter, ...filter },
        })),

      updateCampaignStatus: (id, status) =>
        set((state) => ({
          campaigns: state.campaigns.map((c) =>
            c.id === id ? { ...c, status, updatedAt: new Date() } : c
          ),
        })),

      // Actions - Templates
      addTemplate: (template) =>
        set((state) => ({
          templates: [template, ...state.templates],
        })),

      updateTemplate: (id, updates) =>
        set((state) => ({
          templates: state.templates.map((t) =>
            t.id === id ? { ...t, ...updates, updatedAt: new Date() } : t
          ),
          selectedTemplate:
            state.selectedTemplate?.id === id
              ? { ...state.selectedTemplate, ...updates, updatedAt: new Date() }
              : state.selectedTemplate,
        })),

      deleteTemplate: (id) =>
        set((state) => ({
          templates: state.templates.filter((t) => t.id !== id),
          selectedTemplate:
            state.selectedTemplate?.id === id ? null : state.selectedTemplate,
        })),

      selectTemplate: (template) => set({ selectedTemplate: template }),

      // Actions - Segmentos
      addSegment: (segment) =>
        set((state) => ({
          segments: [segment, ...state.segments],
        })),

      updateSegment: (id, updates) =>
        set((state) => ({
          segments: state.segments.map((s) =>
            s.id === id ? { ...s, ...updates, updatedAt: new Date() } : s
          ),
          selectedSegment:
            state.selectedSegment?.id === id
              ? { ...state.selectedSegment, ...updates, updatedAt: new Date() }
              : state.selectedSegment,
        })),

      deleteSegment: (id) =>
        set((state) => ({
          segments: state.segments.filter((s) => s.id !== id),
          selectedSegment:
            state.selectedSegment?.id === id ? null : state.selectedSegment,
        })),

      selectSegment: (segment) => set({ selectedSegment: segment }),

      // Actions - SMTP
      addSmtpConfig: (config) =>
        set((state) => ({
          smtpConfigs: [config, ...state.smtpConfigs],
        })),

      updateSmtpConfig: (id, updates) =>
        set((state) => ({
          smtpConfigs: state.smtpConfigs.map((s) =>
            s.id === id ? { ...s, ...updates, updatedAt: new Date() } : s
          ),
          selectedSmtpConfig:
            state.selectedSmtpConfig?.id === id
              ? { ...state.selectedSmtpConfig, ...updates, updatedAt: new Date() }
              : state.selectedSmtpConfig,
        })),

      deleteSmtpConfig: (id) =>
        set((state) => ({
          smtpConfigs: state.smtpConfigs.filter((s) => s.id !== id),
          selectedSmtpConfig:
            state.selectedSmtpConfig?.id === id ? null : state.selectedSmtpConfig,
        })),

      selectSmtpConfig: (config) => set({ selectedSmtpConfig: config }),

      setDefaultSmtpConfig: (id) =>
        set((state) => ({
          smtpConfigs: state.smtpConfigs.map((s) => ({
            ...s,
            isDefault: s.id === id,
          })),
        })),

      // Actions - Réguas
      addCommunicationRule: (rule) =>
        set((state) => ({
          communicationRules: [rule, ...state.communicationRules],
        })),

      updateCommunicationRule: (id, updates) =>
        set((state) => ({
          communicationRules: state.communicationRules.map((r) =>
            r.id === id ? { ...r, ...updates, updatedAt: new Date() } : r
          ),
          selectedRule:
            state.selectedRule?.id === id
              ? { ...state.selectedRule, ...updates, updatedAt: new Date() }
              : state.selectedRule,
        })),

      deleteCommunicationRule: (id) =>
        set((state) => ({
          communicationRules: state.communicationRules.filter((r) => r.id !== id),
          selectedRule:
            state.selectedRule?.id === id ? null : state.selectedRule,
        })),

      selectCommunicationRule: (rule) => set({ selectedRule: rule }),

      // Actions - Mensagens
      setCampaignMessages: (messages) => set({ campaignMessages: messages }),

      // Actions - Stats
      setDashboardStats: (stats) => set({ dashboardStats: stats }),
      setQueueStats: (stats) => set({ queueStats: stats }),

      // Actions - UI
      setLoading: (loading) => set({ isLoading: loading }),
      setActiveTab: (tab) => set({ activeTab: tab }),

      // Helpers
      getFilteredCampaigns: () => {
        const { campaigns, campaignFilter } = get();
        return campaigns.filter((c) => {
          if (campaignFilter.status && c.status !== campaignFilter.status) return false;
          if (campaignFilter.channel && c.channel !== campaignFilter.channel) return false;
          if (
            campaignFilter.search &&
            !c.name.toLowerCase().includes(campaignFilter.search.toLowerCase())
          )
            return false;
          return true;
        });
      },

      getTemplatesByChannel: (channel) => {
        return get().templates.filter((t) => t.channel === channel && t.isActive);
      },

      getDefaultSmtpConfig: () => {
        return get().smtpConfigs.find((s) => s.isDefault && s.isActive);
      },
    }),
    {
      name: 'vinculo-engage-storage',
      partialize: (state) => ({
        campaigns: state.campaigns,
        templates: state.templates,
        segments: state.segments,
        smtpConfigs: state.smtpConfigs,
        communicationRules: state.communicationRules,
      }),
    }
  )
);
