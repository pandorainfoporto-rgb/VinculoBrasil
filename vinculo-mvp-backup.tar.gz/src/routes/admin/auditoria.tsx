import { createFileRoute } from '@tanstack/react-router';
import { AdminAuditDashboard } from '@/components/admin-audit-dashboard';

export const Route = createFileRoute('/admin/auditoria')({
  component: AuditoriaPage,
});

function AuditoriaPage() {
  return <AdminAuditDashboard />;
}
