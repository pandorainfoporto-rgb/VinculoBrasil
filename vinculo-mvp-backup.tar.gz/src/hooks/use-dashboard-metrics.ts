/**
 * Hook para metricas do Dashboard Admin
 *
 * Busca contagens reais de:
 * - Tickets/Conversas abertos
 * - Disputas pendentes
 * - Vistorias pendentes
 * - KYC pendentes
 * - Contratos ativos
 * - Receita mensal
 */

import { useQuery } from '@tanstack/react-query';

// ============================================
// TIPOS
// ============================================

export interface DashboardMetrics {
  // Metricas principais
  tvl: number;
  activeContracts: number;
  monthlyRevenue: number;
  revenueGrowth: number;

  // Notificacoes (badges do menu)
  openTickets: number;
  openDisputes: number;
  pendingKYC: number;
  pendingInspections: number;

  // Metricas secundarias
  totalProperties: number;
  totalTenants: number;
  totalLandlords: number;
  totalGuarantors: number;
}

// ============================================
// API FUNCTIONS
// ============================================

async function fetchDashboardMetrics(): Promise<DashboardMetrics> {
  // Busca metricas de varias APIs em paralelo
  const [
    ticketsRes,
    contractsRes,
    propertiesRes,
    usersRes,
  ] = await Promise.allSettled([
    fetch('/api/tickets?status=OPEN&limit=1').then(r => r.json()),
    fetch('/api/contracts?status=active&limit=1').then(r => r.json()),
    fetch('/api/properties?limit=1').then(r => r.json()),
    fetch('/api/users?limit=1').then(r => r.json()),
  ]);

  // Extrai contagens das respostas
  const ticketsData = ticketsRes.status === 'fulfilled' ? ticketsRes.value : { total: 0 };
  const contractsData = contractsRes.status === 'fulfilled' ? contractsRes.value : { total: 0, tvl: 0 };
  const propertiesData = propertiesRes.status === 'fulfilled' ? propertiesRes.value : { total: 0 };
  const usersData = usersRes.status === 'fulfilled' ? usersRes.value : { total: 0 };

  // Calcula metricas baseadas nos dados reais
  return {
    // Metricas principais (alguns valores estimados ate termos APIs completas)
    tvl: contractsData.tvl || 0,
    activeContracts: contractsData.total || 0,
    monthlyRevenue: contractsData.monthlyRevenue || 0,
    revenueGrowth: contractsData.revenueGrowth || 0,

    // Notificacoes - baseadas em contagens reais
    openTickets: ticketsData.total || 0,
    openDisputes: 0, // Sera implementado quando tivermos API de disputas
    pendingKYC: 0, // Sera implementado quando tivermos API de KYC
    pendingInspections: 0, // Sera implementado quando tivermos API de vistorias

    // Metricas secundarias
    totalProperties: propertiesData.total || 0,
    totalTenants: usersData.totalTenants || 0,
    totalLandlords: usersData.totalLandlords || 0,
    totalGuarantors: usersData.totalGuarantors || 0,
  };
}

// ============================================
// HOOKS
// ============================================

/**
 * Hook para buscar metricas do dashboard
 * Atualiza automaticamente a cada 60 segundos
 */
export function useDashboardMetrics() {
  return useQuery({
    queryKey: ['dashboard-metrics'],
    queryFn: fetchDashboardMetrics,
    staleTime: 30 * 1000, // 30 segundos
    refetchInterval: 60 * 1000, // Refetch a cada 60 segundos
    // Valores padrao enquanto carrega
    placeholderData: {
      tvl: 0,
      activeContracts: 0,
      monthlyRevenue: 0,
      revenueGrowth: 0,
      openTickets: 0,
      openDisputes: 0,
      pendingKYC: 0,
      pendingInspections: 0,
      totalProperties: 0,
      totalTenants: 0,
      totalLandlords: 0,
      totalGuarantors: 0,
    },
  });
}
